<?php
include('./include/dbconnection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="./bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="./bootstrap-icons/font/bootstrap-icons.css">
	<script href="./bootstrap/js/bootstrap.bundle.js"></script>
    <script src="js/jquery.min.js"></script>
    <!-- <style>
       <!--*{
            margin:0px;
            padding:0px;
            box-sizing: border-box;
            
        }
        .section{
            width:100%;
            min-height: 100vh;
            background-color: #ddd;
        }
        .container{
            width:80%;
            display:block;
            margin: auto;
            padding-top:100px;
        }
        .content-section{
            float:left;
            width: 55%;
        }
        .image-section{
            float:right;
            width:40%;

        }
        .image-section img{
            width: 100%;
            height: auto;
        }
        .content-section .content h3{
            margin-top: 20px;
            color:#5d5d5d;
        }
        .content-section .content p{
            margin-top: 10px;
            font-family: sans-serif;
            font-size:30px;
            line-height: 1.5;
        }
    </style> -->
    <style>
            body{
                background-image: url('./include/images/main.jpg');

            }
            .top{
                margin-top:150px;
            }
            .imagee{
                height: 100%;
                margin-top:150px;
                border: 10px solid white;
            }
            /* .row img{
                height:300px;
                width:400px;
                margin-top: 10%;     
                margin-left: 10%; 
                
            } */
    </style>
</head>
<body>
    <?php include('./include/header1.php'); ?>
  <div class="container">
    <div class="row">
        <div class="col-md-5">
            <img src="./include/images/33.jpg" class="imagee">
        </div>
        <div class="col-md-7 text-light top">
            <h3>Online DJManagement</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus nulla quis quas modi, dicta dignissimos molestiae quasi laborum debitis, cumque cum nemo, similique officia rem itaque. Quaerat quae itaque deleniti?</p>
        </div>
    </div>
    <div class="row" style="margin-top:30px;">
        <div class="col-md-7 text-light top">
            <h3> abc</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste distinctio, neque temporibus optio possimus quos eaque quam maxime architecto, molestiae ullam! Necessitatibus animi ab, exercitationem minima possimus illo fugiat ea.</p>
        </div>
        <div class="col-md-5">
            <img src="./include/images/33.jpg" class="imagee">
        </div>
    </div>
  </div>
<!-- </div> -->
            <!-- <div class="row">
                <div class="col-md-7">
                    <img  src="./include/images/33.jpg" alt="image">
                </div>
                <div class="col-md-5">
                    <p>hshdhsdhsdhsydgsygdysgdygsdysg</p>
                </div>
            </div> -->
            <!-- <div class="social">
                <a href=""><i class="fab fa-facebook-f"></i></a>
                <a href=""><i class="fab fa-twitter"></i></a>
                <a href=""><i class="fab fa-instagram"></i></a>
            </div> -->
        <!-- </div> -->
        <!-- <div class="image-section">
            <img src="./include/images/33.jpg" alt="image" class="src">
        </div> -->
    <!-- </div>

    </div> -->
</body>
</html>