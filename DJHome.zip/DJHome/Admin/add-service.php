<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link   rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <script  src="../bootstrap/js/bootstrap.bundle.js"></script>
    <title>Add Services</title>
    <style>
        .form{
            margin-left: 25%;
            box-sizing: border-box;
            margin-top: 10%;
        }
    </style>
</head>
<body>
    <?php include('./sidebar.php');
    if(isset($_POST['submit'])){
      $name=$_POST['name'];
      $des=$_POST['des'];
      $price=$_POST['price'];
  
      $sql="insert into tblservice(ServiceName,SerDes,ServicePrice) values('$name','$des','$price')";
      $result=mysqli_query($con,$sql);
    }
    ?>
    <div class="container">
        <h4>Add Service</h4>
        <div class="form">
        <nav class="navbar bg-primary text-white" >
        <div class="container-fluid">
        <a class="text-white " href="#">Add Service</a>
        </div>
        </nav>

        <form  method="post">
        <div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label mt-3">Service name :</label>
  <input type="text" name="name"class="form-control" id="exampleFormControlInput1" >
</div>
<div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">Service Description</label>
  <textarea class="form-control"name="des" id="exampleFormControlTextarea1" rows="3"></textarea>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Service Price :</label>
  <input type="text" name="price"class="form-control" id="exampleFormControlInput1" >
  <button type="submit" name ="submit"class="btn btn-secondary mt-3" >+Add</button>
</div>
        </div>
        </form>
    </div>
</body>
</html>