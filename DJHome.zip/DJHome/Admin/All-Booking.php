<?php 
include('../include/dbconnection.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Booking</title>
    <link   rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link   rel="stylesheet" href="../bootstrap-icons/font/bootstrap-icons.css">

    <script  src="../bootstrap/js/bootstrap.bundle.js"></script>
    <?php include('./sidebar.php')?>
    <style>
        .content{
            margin-left: 24%;
            margin-right: 10px;
           
        }
        .block{
            margin-top: 10%;
        }
    </style>
</head>
<body>
<main id="main-container">
                <!-- Page Content -->
                <div class="content">
                    <h4 class="content-heading">All Booking</h4>
                    

                   

                    <!-- Dynamic Table Full Pagination -->
                    <div class="block">
                    <nav class="navbar bg-body-tertiary"  style="background-color: #e3f2fd;">
  <div class="container-fluid">
    <a class="navbar-brand">All Booking</a>
    <form class="d-flex" role="search">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success" type="submit">Search</button>
    </form>
  </div>
</nav>
                        <div class="block-content block-content-full">
                            <!-- DataTables init on table by adding .js-dataTable-full-pagination class, functionality initialized in js/pages/be_tables_datatables.js -->
                            <table class="table table-bordered table-striped table-vcenter js-dataTable-full-pagination">
                                <thead>
                                    <tr>
                                        
                                        <th>Booking ID</th>
                                        <th class="d-none d-sm-table-cell">Cutomer Name</th>
                                        <th class="d-none d-sm-table-cell">Mobile Number</th>
                                        <th class="d-none d-sm-table-cell">Email</th>
                                        <th class="d-none d-sm-table-cell">Booking Date</th>
                                        <th class="d-none d-sm-table-cell">Status</th>
                                        
                                       </tr>
                                       
                                </thead>
                                <tbody>
                                    <?php
$sql="SELECT * from tblbooking ";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_assoc($result))
{
    $id=$row['BookingID'];
  $name=$row['Name'];
  $number=$row['MobileNumber'];
  $mail=$row['Email'];
  $date=$row['BookingDate'];
  $status=$row['Status'];
    echo'
    <tr>
    <th scope="row">'.$id.'</th>
    <td>'.$name.'</td>
    <td>'.$number.'</td>
    <td>'.$mail.'</td>
    <td>'.$date.'</td>
    <td>'.$status.'</td>
    
    ';
}

                                
                                  ?>
                                  
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Dynamic Table Full Pagination -->

                    <!-- END Dynamic Table Simple -->
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->


    
</body>
</html>