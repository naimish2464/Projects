
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class showuserservlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            resp.setContentType("text/html");
            PrintWriter out = resp.getWriter();

            out.print("<a href=\"/crudservlet/index.html\">Add User</a>");
            out.print("<a href=\"/crudservlet/showuserservlet\">Show User</a>");
            out.println("<br>Show user page");

            out.println("<table border=\"1\"><tr><th>Id</th><th>Name</th><th>Age</th><th>Gender</th><th>City</th><th>Edit</th><th>Delete</th></tr>");
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "");
            PreparedStatement ps = conn.prepareStatement("select * from stud");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>"+rs.getInt("id")+"</td>");
                out.println("<td>"+rs.getString("name")+"</td>");
                out.println("<td>"+rs.getInt("age")+"</td>");
                out.println("<td>"+rs.getString("gender")+"</td>");
                out.println("<td>"+rs.getString("city")+"</td>");
                out.println("<td><a href='editservlet?id="+rs.getInt("id")+"'>Edit</a></td>");
                out.println("<td><a href='deleteservlet?id="+rs.getInt("id")+"'>Delete</a></td>");
                out.println("</tr>");
            }
            out.println("</table >");

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(showuserservlet.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
