
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class editservlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            resp.setContentType("text/html");
            PrintWriter out = resp.getWriter();
            String id = req.getParameter("id");
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "");
            PreparedStatement ps = conn.prepareStatement("select * from stud where id='" + id + "'");
            ResultSet rs = ps.executeQuery();
            rs.next();
            out.println("<form method=\"post\" action=\"updateservlet?id="+rs.getString("id")+"\">");
            out.println("");
            out.println("<table border=\"1\">");
            out.println("<tr>");
            out.println("<td>Enter a name</td>");

            out.println("<td><input type=\"text\" name=\"name\" required=\"\" value=\"" + rs.getString("name") + "\" /></td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td>Enter a age</td>");
            out.println("<td><input type=\"text\" name=\"age\" required=\"\" value=" + rs.getString("age") + " /></td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td>gender</td>");
            out.println("<td>");
            if (rs.getString("gender").equalsIgnoreCase("male")) {
                out.println("<input type=\"radio\" name=\"gender\" value=\"male\" checked />Male");
            } else {
                out.println("<input type=\"radio\" name=\"gender\" value=\"male\"/>Male");
            }
            if (rs.getString("gender").equalsIgnoreCase("female")) {
                out.println("<input type=\"radio\" name=\"gender\" value=\"female\" checked />Female");
            } else {
                out.println("<input type=\"radio\" name=\"gender\" value=\"female\" />Female");
            }

            out.println("<td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td>Enter a name</td>");
            out.println("<td><select name=\"city\">");
            if (rs.getString("city").equals("surat")) {
                out.println("<option value=\"surat\" selected>Surat</option>");
            } else {
                out.println("<option value=\"surat\">Surat</option>");
            }
            if (rs.getString("city").equals("pune")) {
                out.println("<option value=\"pune\" selected>Pune</option>");
            } else {
                out.println("<option value=\"pune\">Pune</option>");
            }
            if (rs.getString("city").equals("udaipur")) {
                out.println("<option value=\"udaipur\" selected>Udaipur</option>");
            } else {
                out.println("<option value=\"udaipur\">Udaipur</option>");
            }
            out.println("</select>");
            out.println("</td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td colspan=\"2\"><input type=\"submit\" name=\"submit\" value=\"Insert\" /></td>");
            out.println("</tr>");
            out.println("</table></form>");

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(deleteservlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
