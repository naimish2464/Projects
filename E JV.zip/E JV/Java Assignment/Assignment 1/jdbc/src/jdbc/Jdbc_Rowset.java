package jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;

public class Jdbc_Rowset {

    static String url = "jdbc:mysql://localhost:3306/student";
    static String driver = "com.mysql.jdbc.Driver";
    static JdbcRowSet rs = null;
    static Connection conn = null;
    Scanner kk = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            RowSetFactory rsf = RowSetProvider.newFactory();

            rs = rsf.createJdbcRowSet();

            Class.forName(driver);
            rs.setUrl(url);
            rs.setUsername("root");
            rs.setPassword("");

            Jdbc_Rowset obj = new Jdbc_Rowset();
            int ch;
            do {
                System.out.println("||-----------------------Row Set-----------------------||");
                System.out.println("1.Insert");
                System.out.println("2.Update");
                System.out.println("3.Delete");
                System.out.println("4.Display");
                System.out.println("0.Exit");
                System.out.println("Enter your choice:- ");
                ch = obj.kk.nextInt();
                switch (ch) {
                    case 1:
                        obj.insert();
                        break;
                    case 2:
                        obj.update();
                        break;
                    case 3:
                        obj.delete();
                        break;
                    case 4:
                        obj.display();

                }
            } while (ch != 0);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Jdbc_Rowset.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void insert() throws SQLException {
        rs.setCommand("select * from stud");
        rs.execute();
        rs.moveToInsertRow();
        System.out.println("Enter a name:- ");
        String name = kk.next();
        System.out.println("Enter a age:- ");
        int age = kk.nextInt();
        System.out.println("Enter a gender:- ");
        String gender = kk.next();
        System.out.println("Enter a city:- ");
        String city = kk.next();
        rs.updateString("name", name);
        rs.updateInt("age", age);
        rs.updateString("gender", gender);
        rs.updateString("city", city);
        rs.insertRow();
    }

    private void update() throws SQLException {
        System.out.println("Enter a id:- ");
        int id = kk.nextInt();
        rs.setCommand("select * from stud");
        rs.execute();
        System.out.println("Enter a name:- ");
        String name = kk.next();
        System.out.println("Enter a age:- ");
        int age = kk.nextInt();
        System.out.println("Enter a gender:- ");
        String gender = kk.next();
        System.out.println("Enter a city:- ");
        String city = kk.next();
        rs.setCommand("select * from stud");
        rs.execute();
        while (rs.next()) {
            if (rs.getInt("id") == id) {
                rs.updateString("name", name);
                rs.updateInt("age", age);
                rs.updateString("gender", gender);
                rs.updateString("city", city);
                rs.updateRow();
                return;
            }
        }
    }

    private void delete() throws SQLException {
        rs.setCommand("select * from stud");
        rs.execute();
        System.out.println("Enter a id:- ");
        int id = kk.nextInt();
        while (rs.next()) {
            if (rs.getInt("id") == id) {
                rs.deleteRow();
                return;
            }
        }
    }

    private void display() throws SQLException {
        rs.setCommand("select * from stud");
        rs.execute();
        while (rs.next()) {
            System.out.print(rs.getInt("id") + " ");
            System.out.print(rs.getString("name") + " ");
            System.out.print(rs.getInt("age") + " ");
            System.out.print(rs.getString("gender") + " ");
            System.out.print(rs.getString("city") + "\n");
        }
    }
}
