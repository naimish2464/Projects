package entity;

import java.io.Serializable;

public class Product implements Serializable {

    String pid, pname, price, category,qty;

    public String getPid() {
        return pid;
    }

    public String getPname() {
        return pname;
    }

    public String getPrice() {
        return price;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    
    public void setQty(String qty)
    {
        this.qty=qty;
    }

    public String getQty() {
        return qty;
    }

    
    
}