package ProductHandler;

import entity.Product;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    Connection conn = null;

    public ProductDAO() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        String dburl = "jdbc:mysql://localhost:3306/student";
        conn = DriverManager.getConnection(dburl, "root", "");
    }

    public void insert(Product p) throws SQLException {
        PreparedStatement ps = conn.prepareStatement("insert into product values(?,?,?,?)");
        ps.setString(1, p.getPid());
        ps.setString(2, p.getPname());
        ps.setString(3, p.getPrice());
        ps.setString(4, p.getCategory());
        ps.executeUpdate();
    }

    public List display() throws SQLException {
        ArrayList<Product> list = new ArrayList<>();
        PreparedStatement ps = conn.prepareStatement("select * from product");
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Product p = new Product();
            p.setPid(rs.getString("pid"));
            p.setPname(rs.getString("pname"));
            p.setPrice(rs.getString("price"));
            p.setCategory(rs.getString("category"));
            list.add(p);
        }
        return list;
    }

    public void delete(Product p) throws SQLException {
        PreparedStatement ps = conn.prepareStatement("delete from product where pid=?");
        ps.setString(1, p.getPid());
        ps.executeUpdate();
    }
    public Product getdata(Product p) throws SQLException
    {
        PreparedStatement ps = conn.prepareStatement("select * from product where pid=?");
        ps.setString(1, p.getPid());
        ResultSet rs = ps.executeQuery();
        Product p1=new Product();
        rs.next();
        p1.setPid(rs.getString("pid"));
        p1.setPname(rs.getString("pname"));
        p1.setPrice(rs.getString("price"));
        p1.setCategory(rs.getString("category"));
        return p1;
    }
    public void update(Product p) throws SQLException
    {
        PreparedStatement ps=conn.prepareStatement("update product set pname=?,price=?,category=? where pid=? ");
        ps.setString(1, p.getPname());
        ps.setString(2, p.getPrice());
        ps.setString(3, p.getCategory());
        ps.setString(4, p.getPid());
        ps.executeUpdate();
    }
}
