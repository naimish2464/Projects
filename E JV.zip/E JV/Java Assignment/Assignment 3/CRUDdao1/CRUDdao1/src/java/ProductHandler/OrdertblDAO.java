package ProductHandler;

import entity.Ordertbl;
import entity.Product;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class OrdertblDAO {
    Connection conn = null;

    public OrdertblDAO() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        String dburl = "jdbc:mysql://localhost:3306/student";
        conn = DriverManager.getConnection(dburl, "root", "");
    }
    
    public void insert(Ordertbl o) throws SQLException {
        PreparedStatement ps = conn.prepareStatement("insert into ordertbl values(?,?,?,?)");
        ps.setString(1, o.getOid());
        ps.setString(2, o.getPid());
        ps.setString(3, o.getQty());
        ps.setString(4, o.getId());
        ps.executeUpdate();
    }
}