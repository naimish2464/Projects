 package SessionBean;

import ProductHandler.CartDAO;
import entity.Product;
import entity.cart;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;

@Stateless
public class AddToBean {

    List<Product> list = new ArrayList<>();

    public void add(Product p) {
        list.add(p);
    }

    public void removeit(Product p,String cid) {

        for (Product pobj : list) {
            if (pobj.getPid().equals(p.getPid())) {
                try {
                    CartDAO cdao=new CartDAO();
                    cdao.removeCart(pobj.getPid(), cid);
                    list.remove(pobj);
                } catch (SQLException ex) {
                    Logger.getLogger(AddToBean.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(AddToBean.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        
    }

    public List fetchData() {
        return list;
    }

    public void clearCart() {
        list.clear();
    }

    public boolean checkData(Product p) {
        for (Product pobj : list) {
            if (pobj.getPid().equals(p.getPid())) {
                return false;
            }
        }
        return true;
    }

    public void maintainQty(String id) {

        for (Product pobj : list) {
            if (pobj.getPid().equals(id)) {
                int qty = Integer.parseInt(pobj.getQty());

                qty = qty + 1;

                pobj.setQty(String.valueOf(qty));
            }
        }
    }

    public void maintainQty1(String id) {

        for (Product pobj : list) {
            if (pobj.getPid().equals(id)) {
                int qty = Integer.parseInt(pobj.getQty());
                if (qty > 1) {
                    qty = qty - 1;
                }

                pobj.setQty(String.valueOf(qty));
            }
        }
    }

    public void addtocart(String cid) throws ClassNotFoundException, SQLException {        
        cart c;
        for (Product pobj : list) {
            c = new cart();
            int total = 0;
            c.setCartid(null);
            c.setPid(pobj.getPid());
            c.setPname(pobj.getPname());
            c.setPrice(pobj.getPrice());
            c.setCategory(pobj.getCategory());
            c.setQty(pobj.getQty());
            c.setSubtotal(String.valueOf(Integer.parseInt(pobj.getQty()) * Integer.parseInt(pobj.getPrice())));
            c.setCid(cid);
            CartDAO cdao=new CartDAO();
            cdao.insert(c,cid);
        }
    }
}