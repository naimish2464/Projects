package ProductHandler;

import entity.cart;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CartDAO {

    Connection conn = null;

    public CartDAO() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        String dburl = "jdbc:mysql://localhost:3306/student";
        conn = DriverManager.getConnection(dburl, "root", "");
    }

    public void insert(cart c, String uid) throws SQLException {
        PreparedStatement check = conn.prepareStatement("select * from cart where pid=? and cid=?");
        check.setString(1, c.getPid());
        check.setString(2, uid);
        ResultSet rs = check.executeQuery();
        if (rs.next()) {
            if (!c.getQty().equals(rs.getString("qty"))) {
                PreparedStatement updateqty = conn.prepareStatement("update cart set qty=? where pid=? and cid=?");
                updateqty.setString(1, c.getQty());
                updateqty.setString(2, c.getPid());
                updateqty.setString(3, uid);
                updateqty.executeUpdate();
            }
        } else {
            PreparedStatement ps = conn.prepareStatement("insert into cart values(?,?,?,?,?,?,?,?)");
            ps.setString(1, null);
            ps.setString(2, c.getPid());
            ps.setString(3, c.getPname());
            ps.setString(4, c.getPrice());
            ps.setString(5, c.getCategory());
            ps.setString(6, c.getQty());
            ps.setString(7, c.getSubtotal());
            ps.setString(8, c.getCid());
            ps.executeUpdate();
        }

    }
    public void removeCart(String pid,String cid) throws SQLException
    {
        PreparedStatement ps = conn.prepareStatement("delete from cart where pid=? and cid=?");
        ps.setString(1, pid);
        ps.setString(2, cid);
        ps.executeUpdate();
    }
}
