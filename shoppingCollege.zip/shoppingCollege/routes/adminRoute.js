const express=require('express');

const adminModel=require('../models/adminSchema')

const router=express.Router();


router.post('/regAdmin',async(req,res)=>{

    try {
        const{email,password}=req.body;
        
        if(!email){
            return res.send({
                error:"email is required"
            })
        }
        if(!password){
            return res.send({
                error:"password is required"
            })
        }
        //existing user
        const existuser=await adminModel.findOne({email});
        if(existuser){
            return res.send({
                success:false,
                message:'user is alrewaduy exist'
            })
        }

        const user=new adminModel({email,password});
        await user.save();
        res.send({success:true,message:'admin created successfully'})
        console.log(user);


        
    } catch (error) {
        console.log(error);
    }
   
 });


router.post("/login",async (req,res)=>{
    if(req.body.password && req.body.email){
        let user=await adminModel.findOne(req.body).select("-password");
        if(user){
            res.send(user);
        }else{
            res.send({res:"no user found"});
        }
    }else{
        res.send({res:"user not found"});
    }
})

module.exports=router