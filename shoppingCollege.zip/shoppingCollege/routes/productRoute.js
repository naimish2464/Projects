const express = require('express');
const productModel=require('../models/productSchema');
const router=express.Router();
const app=express();
const fileupload=require('express-fileupload');
app.use(fileupload({}))
router.post('/create-product',async(req,res)=>{
    try {
        const { name, desc, price, quantity } =
        req.body;
        const { photo } = req.files;
        console.log(req.files)
        //alidation
        switch (true) {
          case !name:
            return res.status(500).send({ error: "Name is Required" });
          case !desc:
            return res.status(500).send({ error: "Description is Required" });
          case !price:
            return res.status(500).send({ error: "Price is Required" });
         
          case !quantity:
            return res.status(500).send({ error: "Quantity is Required" });
          case photo && photo.size > 1000000:
            return res
              .status(500)
              .send({ error: "photo is Required and should be less then 1mb" });
        }
    
        const products = new productModel({name, desc, price, quantity,photo});
        if(photo){
          products.photo.contentType=photo.type;
        }
       
        await products.save();
        res.status(201).send({
          success: true,
          message: "Product Created Successfully",
          products,
        });
      } catch (error) {
        console.log(error);
        res.status(500).send({
          success: false,
          error,
          message: "Error in crearing product",
        });
      }
    }
    


)

router.get('/getprod',async(req,res)=>{
  try {
    const products = await productModel.find({})
    
    res.status(200).send({
      success: true,
      counTotal: products.length,
      message: "ALlProducts ",
      products,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Erorr in getting products",
      error: error.message,
    });
  }
})

module.exports=router;