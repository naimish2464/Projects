 const express=require('express');

 const router=express.Router();
 const userModel=require('../models/userModel')

 //reg
 router.post('/reg',async(req,res)=>{

    try {
        const{name,email,password}=req.body;
        if(!name){
            return res.send({
                error:"name is required"
            })
        }
        if(!email){
            return res.send({
                error:"email is required"
            })
        }
        if(!password){
            return res.send({
                error:"password is required"
            })
        }
        //existing user
        const existuser=await userModel.findOne({email});
        if(existuser){
            return res.send({
                success:false,
                message:'user is alrewaduy exist'
            })
        }

        const user=new userModel({name,email,password});
        await user.save();
        res.send({success:true,message:'user created successfully'})


        
    } catch (error) {
        console.log(error);
    }
   
 });

 router.post("/login",async (req,res)=>{
    if(req.body.password && req.body.email){
        let user=await userModel.findOne(req.body).select("-password");
        if(user){
            res.send(user);
        }else{
            res.send({res:"no user found"});
        }
    }else{
        res.send({res:"user not found"});
    }
})


 module.exports=router;