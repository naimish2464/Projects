const mongoose=require('mongoose');

const connectDb=async()=>{
    try {
        const db=await mongoose.connect('mongodb://localhost:27017/shoppingCart');
        if(db){
            console.log("the database is connected");
        }
        
    } catch (error) {
        console.log(error);

        
    }
   
}

module.exports=connectDb;