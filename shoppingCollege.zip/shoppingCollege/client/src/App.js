
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import SignUp from './components/SignUp';
import Login from './components/Login';
import Product from './components/Product';
import AdminDashbord from './components/AdminDashbord';
import AdminLogin from './components/AdminLogin';
import Showproduct from './components/Showproduct';
function App() {
  return (
    <div  >
    <BrowserRouter>
    <Navbar/>
    <Routes>
    <Route path='/' element={<Showproduct/>}></Route>
    <Route path='/add' element={<Product/>}></Route>
    <Route path='update' element={<h1> update product</h1>}></Route>
    <Route path='/logout' element={<h1>logout product</h1>}></Route>
    <Route path='/profile' element={<h1>profile product</h1>}></Route>
    <Route path='/signup' element={<SignUp/>}></Route>
    <Route path='/login' element={<Login/>}></Route>
    <Route path='/admin' element={<AdminLogin/>}></Route>
    <Route path='/adminDashbord' element={<AdminDashbord/>}></Route>
    </Routes>
    </BrowserRouter>
    <Footer/>

    </div>
  );
}

export default App;
