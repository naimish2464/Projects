import React from 'react'
import { NavLink } from 'react-router-dom'

const AdminDashbord = () => {
  return (
    <div>
    <ul>
    <li><NavLink to='/add'>Add Product</NavLink></li>
    <li><NavLink to=''>delete Product</NavLink></li>
    <li><NavLink to='/update'>update Product</NavLink></li>
    </ul>
    </div>
  )
}

export default AdminDashbord