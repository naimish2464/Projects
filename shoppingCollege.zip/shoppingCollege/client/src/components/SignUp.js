import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

const SignUp = () => {
  const[name,setName]=useState("");
  const[password,setPassword]=useState("");
  const[email,setEmail]=useState(""); 
  const navigate=useNavigate();
  const collectData=async()=>{
    let res=await axios.post('http://localhost:5000/api/user/reg',
    
      {name,email,password}
      
    )
    if(res){
        alert('reg successfully')
        navigate('/login')
    }
    
    localStorage.setItem("user",JSON.stringify(res))
   
    
  }

  return (
    <div style={{marginLeft:'40%', marginTop:'10%',border:'black'}}>
    <h1 style={{width:'30%',textAlign:'center'}}>Ragister</h1>
    <input className='inputbox' type="text" onChange={(e)=>setName(e.target.value )} value={name} placeholder="enter name"></input>
    <input className='inputbox' type="email" onChange={(e)=>setEmail(e.target.value)} value={email} placeholder="Enter email"></input>
    <input className='inputbox' type="password" onChange={(e)=>setPassword(e.target.value)} value={password} placeholder="Enter password"></input>
    <button style={{margin:"25px",padding:"15px",width:'150px',backgroundColor:'skyblue'}} onClick={collectData} type='button'> Sign Up</button>
    </div>
  )
}

export default SignUp

