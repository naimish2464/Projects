import React from 'react'
import { useState, useEffect } from 'react'
import axios from 'axios';

const Showproduct = () => {
  const [products, setProducts] = useState([]);

  const getAllData = async () => {
    const { data } = await axios.get('http://localhost:5000/product/getprod')
    if (data?.success) {
      setProducts(data?.products);
    }
  }

  useEffect(()=>{
    getAllData();

  },[])
  return (
    <>
      <div>Showproduct</div>
      {
        products.map((e) => {
          return <div className="card" style={{width: "18rem"}}>
            <img src={e.photo} className="card-img-top" alt="..."/>
              <div className="card-body">
              <h5 className="card-title">{e.name}</h5>
              <h5 className="card-title">{e.price}</h5>
              <h5 className="card-title">{e.quantity}</h5>
             <button>Add to cart</button>
              </div>
          </div>
        })
      }

    </>


  )
}

export default Showproduct