import React from 'react'
import { useState } from 'react'
import axios from 'axios';

const Product = () => {
    const[name,setName]=useState("");
    const[price,setPrice]=useState("");
    const[desc,setdesc]=useState("");
    const[quantity,setquantity]=useState("");
    const [photo, setPhoto] = useState("");
    const[err,setErr]=useState(false);
    const addProduct=async(e)=>{
      e.preventDefault();
        if(!name||!price||!desc||!quantity){
            setErr(true);
            return false;


        }
        const prodData=new FormData();
        prodData.append('name',name);
        prodData.append('price',price);
        prodData.append('desc',desc);
        prodData.append('quantity',quantity);
        prodData.append('photo',photo);
        const userId=JSON.parse(localStorage.getItem('user'))._id;
        const config={
          headers:{
            'Content-Type': 'multipart/form-data'
          }
        }
        let res=await axios.post("http://localhost:5000/product/create-product",
            
          prodData,config
           

        )
        
        console.log(res);
        alert("data add successfully")
        setName("");
        setPrice("");
        setdesc("");
        setquantity("");
    }
  return (
    <div>
     <h1>Add Products</h1>
     <input type='text' placeholder='Enter Product name' className='inputBox' value={name} onChange={(e)=>setName(e.target.value)}></input>
     {err && !name && <span className='invalid'>Enater valid name</span>}
     <input type='text' placeholder='Enter Product price' className='inputBox' value={price} onChange={(e)=>setPrice(e.target.value)}></input>
     {err && !price && <span className='invalid'>Enater valid price</span>}
     <input type='text' placeholder='Enter Product desc' className='inputBox' value={desc} onChange={(e)=>setdesc(e.target.value)}></input>
     {err && !desc && <span className='invalid'>Enater valid catogary</span>}
     <input type='text' placeholder='Enter Product quntity' className='inputBox' value={quantity} onChange={(e)=>setquantity(e.target.value)}></input>
     {err && !quantity && <span className='invalid'>Enater valid company</span>}
     <input
     type="file"
     name="photo"
    
     accept="image/*"
     onChange={(e) => setPhoto(e.target.files[0])}
    
   />
    
     <button onClick={addProduct} className='appButton'>Add Product</button>
    </div>
  )
}

export default Product