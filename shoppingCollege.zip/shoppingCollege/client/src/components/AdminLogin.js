import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

const AdminLogin = () => {
    const[email,setEmail]=useState("");
    const[password,setPassword]=useState("");
    const navigate=useNavigate();
    const handleLogin=async()=>{
        let result=await axios.post("http://localhost:5000/admin/login",
                {email,password}
                 
    )
    if(result){
        alert('login successfully')
        navigate('/adminDashbord')

    }
    
   

    }

  return (
    <div>

    Email:<input type="email" name="email" placeholder="Enter Here" onChange={(e)=>setEmail(e.target.value)} value={email}/>
    Password:<input type="password" name="password" placeholder="Enter Here" onChange={(e)=>setPassword(e.target.value)} value={password}/>
    <button onClick={handleLogin}>Login</button>
    </div>
  )
}

export default AdminLogin