const express=require('express')
const connectDb=require('./models/db');
const app=express();
const cors=require('cors');
const routes=require('./routes/authRoute')
const adminroute=require('./routes/adminRoute')
const productRoute=require('./routes/productRoute')
const fileupload=require('express-fileupload');


connectDb();

app.use(cors());
app.use(fileupload({
    useTempFiles:true,
    tempFileDir:'public/'
}));

app.use(express.json());
app.use('/api/user',routes)

app.use('/admin',adminroute)

app.use('/product',productRoute)



app.listen(5000,()=>{
    console.log("server is running")
})