#Q1. MEAN , MEDIAN ,MODE
xi = [2,3,5,13,8,16,11,1,9]
yi = [15,28,42,64,50,90,58,8,54]
xi_xb = []
yi_yb = []
xi_xbsq = []
xi_xb_mul_yi_yb = [0,0,0,0,0,0,0,0,0]

xb = sum(xi)/9
yb = sum(yi)/9

print(20*'*','X bar  : ')
for i in xi:
    xi_xb.append(round(i-xb,2))

print(xi_xb)

print(20*'*','Y bar : ')
for j in yi:
    yi_yb.append(round(j-yb,2))

print(yi_yb)

print(20*'*',' Xi-Xbar Square :  ')
for i in xi_xb:
    xi_xbsq.append(round(i*i,2))

print(sum(xi_xbsq))

print(20*'*','Xi-Xbar and Yi-Ybar : ','*'*20)
for i in range(0,9):
    xi_xb_mul_yi_yb[i] = round(xi_xb[i]*yi_yb[i],2)

print(sum(xi_xb_mul_yi_yb))

print(20*'*','Formula for Q1 : ' , 20*'*')
Q1 = sum(xi_xb_mul_yi_yb)/sum(xi_xbsq)
print(round(Q1,3))

print(20*'*','Formula for Q0 : ' , 20*'*')
Q0 = float(yb-(Q1*xb))
print(Q0)
  
print(20*'*','Regression Line : ')
x = 23.5
y  = Q1*x + round(Q0,2)
print(y)


