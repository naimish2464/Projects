import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import linear_model
from sklearn.metrics import r2_score

print("---> start <----")
dataFrame = pd.read_csv('./DATASETS_ML/CO2 Emissions_Canada.csv')
print(dataFrame.head())
print("\n continue......")
print(dataFrame.describe())
print("\n continue......")

plt.scatter(dataFrame.HP,dataFrame.MPG,color="blue")

plt.xlabel("Horse Power")
plt.ylabel("Miles Per Gallon")
plt.show()

dataFrame_x1 = dataFrame[['HP']]
dataFrame_y1 = dataFrame[['MPG']]

x1_train,x1_test,y1_train,y1_test = train_test_split(dataFrame_x1,dataFrame_y1,test_size=0.33,random_state=40)

regression = linear_model.LinearRegression()
regression.fit(x1_train,y1_train)
print("\n\n\n ---------> Coefficient <-------",regression.coef_,"\n\t",regression.intercept_,"\n\t",regression.singular_,"\n\t",regression.rank_)


test_y_hat1 = regression.predict(x1_test)
np.mean(np.absolute(test_y_hat1-y1_test))
msq1 = np.mean((test_y_hat1-y1_test)**2)
print('\n Means Square Error {0}'.format(msq1))
r2_score1 = r2_score(test_y_hat1,y1_test)
print("\n\n Score{0}".format(r2_score1))