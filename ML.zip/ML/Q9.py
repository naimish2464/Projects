#Q9.NAIVE BAYS CLASSIFIER
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris

from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import r2_score

print("\n\n ------------------- START   ------------------- \n\n ")
df = load_iris()
print(df.data)
print(df.target_names[df.target])

x = df.data
y = df.target

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.33,random_state=40)

NB = GaussianNB()
NB.fit(x_train,y_train)

y_pred = NB.predict(x_test)
print(f"\n R2 Score : {r2_score(y_test,y_pred)}")

pred_data = [[1,7,1.4,2.12,1.1]]
Prediction = NB.predict(pred_data)
print(f"\n Type : {df.target_names[Prediction]}")

print("\n\n ------------------- END   ------------------- \n\n")
