# Q5 . COMPARE LINEAR & NON-LINEAR REGRESSION
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import linear_model
from sklearn.metrics import r2_score
from sklearn.preprocessing import PolynomialFeatures

print("---> start <----")
dataFrame = pd.read_csv('./DATASETS_ML/CO2 Emissions_Canada.csv')
print(dataFrame.head())
print("\n continue......")
print(dataFrame.describe())
print("\n continue......")

df_x = dataFrame[["HP"]]
df_y = dataFrame[["CO2_Emmision"]]

plt.scatter(df_x,df_y)
plt.xlabel("Engine Size")
plt.ylabel("CO2_Emmision")
plt.show()



poly_features = PolynomialFeatures(degree=2)
df_x_f= poly_features.fit_transform(df_x)

x1_train,x1_test,y1_train,y1_test = train_test_split(df_x,df_y,test_size=0.33,random_state=40)
x2_train,x2_test,y2_train,y2_test = train_test_split(df_x_f,df_y,test_size=0.33,random_state=40)

Linear_Regr=linear_model.LinearRegression()
Linear_Regr.fit(x1_train,y1_train)

NonLinear_Regr = linear_model.LinearRegression()
NonLinear_Regr.fit(x2_train,y2_train)

test_y_hat1 = Linear_Regr.predict(x2_test)
msqe1 = np.mean(np.absolute(test_y_hat1-y1_test)==2)
r2Score1 = r2_score(test_y_hat1,y1_test)
print("..... Linear Regression ...... ")
print("\n\n Mean Square Error is {0}",format(msqe1))
print("\n\nR2 Score is : {0}",format(r2Score1))


# 
test_y_hat2 = NonLinear_Regr.predict(x2_test)
msqe2 = np.mean(np.absolute(test_y_hat2-y2_test)**2)
r2Score2 = r2_score(test_y_hat2,y1_test)
print("..... NoN Linear Regression ...... ")
print("\n\n Mean Square Error is {0}",format(msqe2))
print("\n\nR2 Score is : {0}",format(r2Score2))






print("\n\n\n-------- END ----------")