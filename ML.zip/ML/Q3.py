# Q3 . MULTIPLE LINEAR REGRESSION USING SCIKIT LEARN  AND LIBRARIES


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import linear_model
from sklearn.metrics import r2_score

print("-- Enter ---- ")
dataFrame = pd.read_csv("./DATASETS_ML/CO2 Emissions_Canada.csv")
print('\n\n\n',dataFrame.head())
print('\n\n\n Continue ')
print('\n\n\n',dataFrame.describe())
print('\n\n\n Continue ')

featureSets = dataFrame[['Cylinders','HP','CO2_Emmisions','Fuel_Consumption_Comb']]
fig,(ax1,ax2,ax3)=plt.subplot(1,3)
fig.suptitle('Horizontally Stacked Subplots')
ax1.scatter(featureSets.Cylinders,featureSets.CO2_Emmisions,color="blue")
ax1.set(xlabel='Cylinders',ylabel='CO2_Emmisions')

ax2.scatter(featureSets.HP,featureSets.CO2_Emmisions,color="blue")
ax2.set(xlabel='HP',ylabel='CO2_Emmisions')

ax3.scatter(featureSets.HP,featureSets.CO2_Emmisions,color="blue")
ax3.set(xlabel='Fuel_Consumption_Comb',ylabel='CO2_Emmisions')

fig.show()

dataFrame_x =  dataFrame[['Cylinders','HP','Fuel_Consumption_Comb']]
dataFrame_y =  dataFrame[['CO2_Emmisions']]
x1_train,x1_test,y1_train,y1_test = train_test_split(dataFrame_x,dataFrame_y,test_size=0.33,random_state=40)

regression=linear_model.LinearRegression()
regression.fit(x1_train,y1_train)
print("\n\n Coefficient :\n\n\t",regression.coef_,"\n\t",regression.intercept_,"\n\t",regression.singular_,"\n\t",regression.rank_)
testing = regression.predict(x1_test)
meanSquare = np.mean((testing-y1_test)**2)
print("\n\n Mean Square Error is {0}",format(meanSquare))
r2_score = r2_score(testing,y1_test)
print("\n\nR2 Score is : {0}",format(r2_score))
print("\n\n\n------end------")