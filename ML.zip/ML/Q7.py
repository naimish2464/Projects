# Q7 . KNN on IRIS DATASET
from sklearn.model_selection import train_test_split
import sklearn as sk
from sklearn import datasets
from sklearn import neighbors

from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

print("\n\n\n ----------------------------- START ------- \n\n")

irisDS = datasets.load_iris()

print(irisDS)
print(type(irisDS))

x = irisDS.data
y = irisDS.data
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.33,random_state=40)

#model fitting
model = sk.neighbors.KNeighborsClassfier(n_neighbors=2,weight='distance',metric="manhattan")
model.fit(x_train,y_train)

testing  = model.predict(x_test)
print("\n\n  --> Iris Type \n ")
print(irisDS.target_names[testing])
print("\n Accuracy Scire : \t",accuracy_score(y_test,testing))

#confusion metrics
print("\n\n Confusion Matrix\n",confusion_matrix(y_test,testing,labels=[0,1,2]))

print("\n\n\n\n\n\n  --------------------- END -------------- \n\n")