# Q4 . SIMPLE NON-LINEAR REGRESSION

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import linear_model
from sklearn.metrics import r2_score
from sklearn.preprocessing import PolynomialFeatures


print("------ START --------- ")
dataFrame = pd.read_csv("./DATASETS_ML/CO2 Emissions_Canada.csv")
print('\n\n\n',dataFrame.head())
print('\n\n\n Continue ')
print('\n\n\n',dataFrame.describe())
print('\n\n\n Continue ')

featureSets = dataFrame[['Cylinders','HP','CO2_Emmisions','Fuel_Consumption_Comb']]
featureSets.hist()
plt.show()

dataFrame_x2 =  dataFrame[['Cylinders','HP','Fuel_Consumption_Comb']]
dataFrame_y1 =  dataFrame[['CO2_Emmisions']]
polynomialFeature = PolynomialFeatures(degree=2)
dataFrame_x1= polynomialFeature.fit_transform(dataFrame_x2)

x1_train,x1_test,y1_train,y1_test = train_test_split(dataFrame_x1,dataFrame_y1,test_size=0.33,random_state=40)

regression=linear_model.LinearRegression()
regression.fit(x1_train,y1_train)
print("\n\n Coefficient :\n\n\t",regression.coef_,"\n\t",regression.intercept_,"\n\t",regression.singular_,"\n\t",regression.rank_)

testing = regression.predict(x1_test)
meanSquare = np.mean((testing-y1_test)**2)
print("\n\n Mean Square Error is {0}",format(meanSquare))
r2_score = r2_score(testing,y1_test)
print("\n\nR2 Score is : {0}",format(r2_score))
print("\n\n\n-------- END ----------")