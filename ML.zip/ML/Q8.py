#Q8. LOGISTIC REGRESSION ON 'DIGITS' DATASET

import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression

print("\n\n ------------------- START   ------------------- \n\n ")
digitDS = load_digits()
print("Image Data Shape",digitDS.data.shape)
print("Label Data Shape ",digitDS.target.shape)

#VISULAZIATION
plt.figure(20,4)
for i,(image,label) in enumerate(zip(digitDS.data[0:5],digitDS.target[0:5])):
    plt.subplot(1,5,i+1)
    plt.imshow(np.reshape(image,(8,8)),cmap=plt.cm.gray)
    plt.title('Label:%i\n'%label,fontsize=20)
    plt.show()

x_train,x_test,y_train,y_test = train_test_split(digitDS.data,digitDS.target,test_size=0.33,random_state=40)

logisticRegression = LogisticRegression(random_state=0,max_iter=10000)
logisticRegression.fit(x_train,y_train)

predict = logisticRegression.predict(x_test)
score = logisticRegression.score(x_test,y_test)
print("\n\n Score is",score)

cm = metrics.confusion_matrix(y_test,predict)
print("\n\n Confusion Matrix \n\n",cm)

print("\n\n ------------------- END   ------------------- \n\n ")
