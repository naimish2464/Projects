#Q6. GRADIENT DECENT

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
# from sklearn import linear_model
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import r2_score


print("---> start <----")
df = pd.read_csv('./DATASETS_ML/CO2 Emissions_Canada.csv')
x = df[['HP']]
y = df[['CO2_Emissions']]
print(df[["HP","CO2_Emissions"]].head(5))

print("Continue.... ")
plt.scatter(x,y)
plt.xlabel("Engine Size")
plt.xlabel("CO2 Emission")
plt.show()

x_train,x_test,y_train,y_test = train_test_split(x,y.values.ravel(),test_size=0.33,random_state=40)

classifier = SGDClassifier(max_iter=1000)
classifier.fit(x_train,y_train)


y_pred= classifier.predict(x_test)
mse = np.mean(np.absolute(y_pred-y_test)**2)
r2Score = r2_score(y_test,y_pred)

print(f"\n\n Mean Square Error : {mse}")
print(f"\n\nR2 Score is :{r2Score}")

pred_x = input("\n\n Enter Size to Predict CO2 Emmission : \t")
print(classifier.predict(pd.DataFrame({"\nEngine_Size" :[pred_x]})))