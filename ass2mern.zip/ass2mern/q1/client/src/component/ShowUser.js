import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { NavLink } from 'react-router-dom';
const ShowUser = () => {
    const [list, setlist] = useState([]);
    const getData = async () => {
        const datas = await axios.get('http://localhost:3001/student/getstud');
        setlist(datas.data);
    }
    const removeData = async (id) => {
        await axios.delete(`http://localhost:3001/student/removestud/${id}`);
        getData();
    }
    const searchItem = async (e) => {
        const item=e.target.value;
        if(item)
        {
            const searchdata=await axios.get(`http://localhost:3001/student/searchstud/${item}`);
            if(searchdata)
            {

                setlist(searchdata.data);
            }
        }
        else
        {
            getData();
        }
    }
    useEffect(() => {
        getData();
    }, [setlist])
    return (
        <>
            
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" onChange={searchItem} />
           
            <table class="table">
                <thead>
                    <tr>
                        <th>FirstName</th>
                        <th>LastName</th>
                        <th>Gender</th>
                        <th>UserName</th>
                        <th>Email</th>
                        <th>MobileNumber</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {list.map((value, key) => (
                        <tr key={key}>
                            <td>{value.fname}</td>
                            <td>{value.lname}</td>
                            <td>{value.gender}</td>
                            <td>{value.uname}</td>
                            <td>{value.email}</td>
                            <td>{value.mno}</td>
                            <td>{value.city}</td>
                            <td>{value.state}</td>
                            <td><button><NavLink to={`/Editstud/${value._id}`}>Edit</NavLink></button></td>
                            <td><button onClick={() => { removeData(value._id) }}>Delete</button></td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </>
    )
}

export default ShowUser