import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
const Editstud = () => {
    const navigate = useNavigate();
    const [firstName, setfirstName] = useState('');
    const [lastName, setlastName] = useState('');
    const [gender, setgender] = useState('');
    const [username, setusername] = useState('');
    const [email, setemail] = useState('');
    const [mno, setmno] = useState('');
    const [city, setcity] = useState('Surat');
    const [state, setstate] = useState('');
    const { id } = useParams();
    const fetchData = async () => {
        const fetch = await axios.get(`http://localhost:3001/student/Editstud/${id}`);
        setfirstName(fetch.data.fname);
        setlastName(fetch.data.lname);
        setgender(fetch.data.gender);
        setusername(fetch.data.uname);
        setemail(fetch.data.email);
        setmno(fetch.data.mno);
        setcity(fetch.data.city);
        setstate(fetch.data.state);

    }
    const updateData = async () => {
        await axios.put(`http://localhost:3001/student/Updatestud/${id}`, {
            firstName,
            lastName,
            gender,
            username,
            email,
            mno,
            city,
            state
        });
        navigate('/display');
    }
    useEffect(() => {
        fetchData();
    }, []);

    return (
        <>
            <div className="regbox">
                <div className="row g-3">
                    <div className="col-sm-6">
                        <label htmlFor="firstName" className="form-label">First name</label>
                        <input type="text" className="form-control" name="firstName" value={firstName} onChange={(e) => { setfirstName(e.target.value) }} placeholder="" required />
                    </div>

                    <div className="col-sm-6">
                        <label htmlFor="lastName" className="form-label">Last name</label>
                        <input type="text" className="form-control" name="lastName" value={lastName} onChange={(e) => { setlastName(e.target.value) }} placeholder="" required />
                    </div>

                    <div className="col-12">
                        <label htmlFor="username" className="form-label">Gender</label>

                        <input type="radio" name="gender" value="male" onChange={(e) => { setgender(e.target.value) }} checked={gender === "male"} />Male
                        <input type="radio" name="gender" value="female" onChange={(e) => { setgender(e.target.value) }} checked={gender === "female"} />Female
                    </div>


                    <div className="col-12">
                        <label htmlFor="username" className="form-label">Username</label>
                        <div className="input-group has-validation">
                            <span className="input-group-text">@</span>
                            <input type="text" className="form-control" name="username" placeholder="" value={username} onChange={(e) => { setusername(e.target.value) }} required />
                        </div>
                    </div>

                    <div className="col-12">
                        <label htmlFor="email" className="form-label">Email</label>
                        <input type="email" className="form-control" name="email" placeholder="" value={email} onChange={(e) => { setemail(e.target.value) }} required />
                    </div>
                    <div className="col-12">
                        <label htmlFor="mno" className="form-label">Mobile Number</label>
                        <input type="number" size="10" className="form-control" name="mno" placeholder="" value={mno} onChange={(e) => { setmno(e.target.value) }} required />
                    </div>
                    <div className="col-sm-6">
                        <label htmlFor="city" className="form-label">City</label>
                        <select name='city' value={city} onChange={(e) => { setcity(e.target.value) }}>
                            <option>Surat</option>
                            <option>Udaipur</option>
                            <option>Pune</option>
                        </select>
                    </div>

                    <div className="col-sm-6">
                        <label htmlFor="state" className="form-label">State</label>
                        <input type="text" className="form-control" name="state" placeholder="" value={state} onChange={(e) => { setstate(e.target.value) }} required />
                    </div>


                    <button className="btn btn-outline-primary mb-3" onClick={() => { updateData(); }}>Register</button>

                </div>
            </div>
        </>
    )
}

export default Editstud
