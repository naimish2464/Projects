import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const initialState = []

export const BlogSlice = createSlice({
    name: "blog",
    initialState,
    reducers: {
        addBlog: (state, action) => {
            axios.post('http://localhost:3001/blog/addblog', action.payload);
        },
        getBlog:(state,action)=>{
            state.push(action.payload);
        },
        clearData:(state,action)=>{
            state.splice(0, state.length);
        }
    }
})

export const { addBlog,getBlog,clearData } = BlogSlice.actions
export default BlogSlice.reducer