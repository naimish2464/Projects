import React, { useEffect } from 'react'
import { addBlog, getBlog,clearData } from './BlogSlice'
import { useDispatch, useSelector } from 'react-redux'
import axios from 'axios'
const ReduxToolkitEx = () => {
    const datalist = useSelector(state => state.blog)
    const setdata = (event) => {
        event.preventDefault();
        const newdata = {
            title: event.target.title.value,
            description: event.target.description.value
        }
        dispatch(addBlog(newdata))
    }
    const getData = async () => {
        const fetchdata = await axios.get('http://localhost:3001/blog/getblog');
        dispatch(clearData())
        fetchdata.data.forEach(element => {
            const awe = {
                title: element.title,
                desc: element.desc
            }
            dispatch(getBlog(awe));
        });
    }
    const dispatch = useDispatch();
    useEffect(() => {
        getData();
    }, [datalist])
    return (
        <>

            <div className="regbox">
                <h1>ReduxToolkitEx</h1>
                <form onSubmit={setdata}>

                    <div className="row g-3">
                        <div className="col-sm-6">
                            <label htmlFor="firstName" className="form-label">Enter Title</label>
                            <input type="text" className="form-control" name="title" placeholder="" required />
                        </div>
                        <div className="col-sm-6">
                            <label htmlFor="firstName" className="form-label">Enter Description</label>
                            <br />
                            <textarea name='description' required></textarea>
                        </div>
                        <input type="submit" className="btn btn-outline-primary mb-3" value="Add" required />
                    </div>
                </form>
                {
                    datalist.map((value, index) => {
                        return (
                            <div className="card" key={index} >
                                <div className="card-body">
                                    <h5 className="card-title">{value.title}</h5>
                                    <p className="card-text">{value.desc}</p>
                                </div>
                            </div>
                        )
                    })
                }
            </div>
        </>

    )
}

export default ReduxToolkitEx