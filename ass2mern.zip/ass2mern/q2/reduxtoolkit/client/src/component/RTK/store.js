import { configureStore } from "@reduxjs/toolkit";
import BlogSlice from "./BlogSlice";
export const store=configureStore({
    reducer:{

        blog:BlogSlice
    }
})