import './App.css';
import ReduxToolKit from './component/RTK/ReduxToolkitEx'
function App() {
  return (
    <div className="App">
      <ReduxToolKit />
    </div>
  );
}
export default App;