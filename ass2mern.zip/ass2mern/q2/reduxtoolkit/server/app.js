const express=require('express');
const routeblog=require('./route/blog_route');
const app=express();
const cors=require('cors');
const mongoose=require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/blog');

app.use(express.json());
app.use(cors());
app.use('/blog',routeblog);
app.listen(3001,()=>{
    console.log("server is running on 3001");
})