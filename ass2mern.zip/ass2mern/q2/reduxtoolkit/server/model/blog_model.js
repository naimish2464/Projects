const mongoose=require('mongoose');
const blogdata=new mongoose.Schema({
    title:{
        type:String
    },
    desc:{
        type:String
    }
})
module.exports=mongoose.model("blogs",blogdata);