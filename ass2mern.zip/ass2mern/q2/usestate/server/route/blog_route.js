const express=require('express');
const blogdata=require('../model/blog_model');
const { default: mongoose } = require('mongoose');
const router=express.Router();

router.post('/addblog',(req,resp)=>{
    const addblog=new blogdata({
        title:req.body.newdata.title,
        desc:req.body.newdata.description
    })
    addblog.save();
})

router.get('/getblog',async(req,res)=>{
    const data=await blogdata.find();
    res.send(data);
})

module.exports=router;