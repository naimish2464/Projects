import './App.css';
import Usestateex from './component/Usestateex'
function App() {
  return (
    <div className="App">
      <Usestateex />
    </div>
  );
}

export default App;
