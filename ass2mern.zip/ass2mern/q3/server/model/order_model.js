const mongoose=require('mongoose');
const ordersch=new mongoose.Schema({
    "name":{
        type:String,
        required:true
    },
    "price":{
        type:String,
        required:true
    },
    "qty":{
        type:String,
        required:true
    },
    "total":{
        type:String,
        required:true
    }
})

module.exports=mongoose.model('products',ordersch);