const express=require('express');
const mongoose=require('mongoose');
const cors=require('cors')
const app=express();
const route=require('./route/billing_route');
mongoose.connect('mongodb://127.0.0.1:27017/orderitem');

app.use(express.json())
app.use(cors())

app.use('/api',route);

app.listen(3001,()=>{
    console.log("server is running at 3001");
})