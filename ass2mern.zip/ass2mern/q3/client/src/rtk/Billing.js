import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import axios from 'axios';
import { addItems, incrementqty, decrementqty } from './BillingSlice'
const Billing = () => {
    const list = useSelector((state) => state.billings)
    const [total, setTotal] = useState(0);
    const dispatch = useDispatch();
    const fetchData = async () => {
        try {
            const response = await axios.get('http://localhost:3001/api/getitems');
            const newData = response.data.map((element) => ({
                _id: element._id,
                name: element.name,
                price: element.price,
                qty: 0,
            }));
            dispatch(addItems(newData));

        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };


    const handleTotal = (value, operation) => {
        setTotal(0);
        let temptotal = total;
        list.map((element) => {
            if (element._id === value._id) {
                if (operation === '+') {
                    temptotal = Number(temptotal) + Number(element.price);
                }
                else if (operation === '-' && element.qty > 0) {
                    temptotal = Number(temptotal) - Number(element.price);
                }
                setTotal(temptotal);
            }


        })

    }


    useEffect(() => {
        fetchData();
    }, [])
    return (
        <h1>
            <div>Redux ToolKit</div>
            {
                list.map((value, key) => (
                    < div Style="display:flex;" key={key} >
                        {value.name} = {value.price}
                        < button onClick={() => { dispatch(decrementqty(value)); handleTotal(value, '-') }} > - </button>{value.qty}
                        <button onClick={() => { dispatch(incrementqty(value)); handleTotal(value, '+'); }}> + </button>{value.price * value.qty}
                    </div >

                )
                )
            }
            <div Style="display:flex;">
                Total = {total}
            </div>
        </h1>
    )
}

export default Billing