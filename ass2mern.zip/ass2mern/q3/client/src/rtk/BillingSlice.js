import { createSlice } from "@reduxjs/toolkit";

const initialState = []

export const BillingSlice = createSlice({
    name: "billings",
    initialState,
    reducers: {
        addItems:(state,action)=>{
            state.length=0;
            state.push.apply(state,action.payload);
        },
        incrementqty:(state,action)=>{
            state.forEach(element=>{
                if(element._id===action.payload._id)
                {
                    element.qty+=1;
                }
            })        
        },
        decrementqty:(state,action)=>{
            state.forEach(element=>{
                if(element._id===action.payload._id)
                {
                    if(element.qty>0)
                    {
                        element.qty-=1;
                    }
                }
            })
        }
    }
})

export const {addItems,incrementqty,decrementqty}=BillingSlice.actions;
export default BillingSlice.reducer;