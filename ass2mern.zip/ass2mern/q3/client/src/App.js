import './App.css';
import Usestateex from './UseState/Usestateex'
import { Route, Routes } from 'react-router-dom';
import Navbar from './UseState/Navbar';
import Billing from './rtk/Billing'
function App() {
  return (
    <div className="App">
      <Navbar/>
      <Routes>
        <Route path='/' exact element={<Usestateex/>}/>
       
        <Route path='/Billing' exact element={<Billing/>}/>
      </Routes>


    </div>
  );
}

export default App;