import React, { useEffect, useState } from 'react'
import axios from 'axios';
const Usestateex = () => {

  const [list, setlist] = useState([])
  const [total, setTotal] = useState(0);
  const fetchData = async () => {
    try {
      const response = await axios.get('http://localhost:3001/api/getitems');
      const newData = response.data.map((element) => ({
        _id: element._id,
        name: element.name,
        price: element.price,
        qty: 0,
      }));
      setlist(newData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleQty = (value, operation) => {
    setTotal(0);
    let temptotal = total;
    const templist = list.map((element) => {
      if (element._id === value._id) {
        if (operation === '+') {
          element.qty += 1;
          temptotal = Number(temptotal) + Number(element.price);
        }
        else if (operation === '-' && element.qty > 0) {
          element.qty -= 1;
          temptotal = Number(temptotal) - Number(element.price);
        }

        setTotal(temptotal);
      }

      return element;
    })
    setlist(templist);
  }
  useEffect(() => {
    fetchData();
  }, [])

  return (
    <>
      <h1>
        <div>UseStateex</div>

        {
          list.map((value, key) => (
            < div Style="display:flex;" key={key} >
              {value.name} = {value.price} < button onClick={() => { handleQty(value, '-') }} > - </button>{value.qty}<button onClick={() => { handleQty(value, '+') }}> + </button>{value.price * value.qty}
            </div >

          )
          )
        }


        <div Style="display:flex;">
          Total = {total}
        </div>
      </h1 >
    </>
  )
}

export default Usestateex