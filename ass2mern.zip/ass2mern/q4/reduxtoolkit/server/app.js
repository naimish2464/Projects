const express=require('express');
const app=express();
const itemrouter=require('./route/item_route')
const cors=require('cors');
const mongoose=require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/itemdb');

app.use(express.json());
app.use(express.static('pubilc'))
app.use(cors());
app.use('/items',itemrouter);

app.listen(3001,()=>{
    console.log("server running at 3001");
})