import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removetocart, clearCart, decrementqty, incrementqty } from './CartSlice';

const Cart = () => {
    const cartItems = useSelector((state) => state.cart);
    const dispatch = useDispatch();
    let total = 0;

    const removeData = (value) => {
        dispatch(removetocart(value));
    };

    const clearData = () => {
        dispatch(clearCart());
    };

    const removeqty = (_id) => {
        dispatch(decrementqty(_id));
    };

    const addqty = (_id) => {
        dispatch(incrementqty(_id));
    };

    const calculateTotalPrice = () => {
        total = cartItems.reduce((acc, item) => {
            acc += item.qty * item.price;
            return acc;
        }, 0);
    };

    return (
        <>
            <h1>Cart</h1>
            <div className='row'>
                {cartItems.map((value, index) => (
                    <div className='col-md-3' key={index}>
                        <div className='card mb-4'>
                            <img src={`./image/${value.img}`} className='card-img-top' alt={value.pname} height='200px' />
                            <div className='card-body'>
                                <h5 className='card-title'>{value.pname}</h5>
                                <p className='card-text'>Rs. {value.price}</p>
                                <div style={{ display: 'flex', justifyContent: 'center' }}>
                                    <button className='btn btn-info' onClick={() => removeqty(value._id)}>
                                        -
                                    </button>
                                    <h3>{value.qty}</h3>
                                    <button className='btn btn-info' onClick={() => addqty(value._id)}>
                                        +
                                    </button>
                                </div>
                                <h3>Total: Rs. {value.qty * value.price}</h3>
                                {calculateTotalPrice()}
                                <button className='btn btn-danger' onClick={() => removeData(value)}>
                                    Remove
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
                <h3>Pay Amount: Rs. {total}</h3>
                <button className='btn btn-warning' onClick={() => clearData()}>
                    Clear Cart
                </button>
            </div>
        </>
    );
};

export default Cart;
