import { createSlice } from "@reduxjs/toolkit";

const initialState = []

export const CartSlice = createSlice({
    name: "cartitem",
    initialState,
    reducers: {
        addtocart(state, action) {
            const found = state.find(item => item._id === action.payload._id)
            if (!found) {
                state.push(action.payload)
            }
        },
        removetocart(state, action) {
            return (
                state.filter((item) => item._id !== action.payload._id)
            )
        },
        clearCart(state) {
            return (state = [])
        },
        decrementqty(state, action) {
            const item = state.find(item => item._id === action.payload);
            if (item && item.qty > 1) {
                item.qty -= 1;
            }
        },
        incrementqty(state, action) {
            const item = state.find(item => item._id === action.payload);
            if (item) {
                item.qty += 1;
            }
        }
    }
});

export const { addtocart, removetocart, clearCart, decrementqty, incrementqty } = CartSlice.actions;

export default CartSlice.reducer;
