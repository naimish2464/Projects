import './App.css';
import Navbar from './component/Navbar';
import { Route, Routes } from 'react-router-dom';
import Product from './component/Product';
import Cart from './component/Cart';
function App() {
  return (
    <div className="App">
      <Navbar />
      <Routes>
        <Route path='/' exact element={<Product />} />
        <Route path='/cart' exact element={<Cart />} />
      </Routes>
    </div>
  );
}

export default App;
