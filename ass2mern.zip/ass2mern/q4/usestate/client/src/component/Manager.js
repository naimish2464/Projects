import React, { useEffect, useState } from 'react';
import MainContext from './MainContext';

const Manager = (props) => {
  const [cartItems, setCartItems] = useState([]);
  const [bill, setBill] = useState({});
  useEffect(() => {

    const initialBill = {};
    for (const item of cartItems) {
      initialBill[item._id] = 1;
    }
    setBill(initialBill);
  }, [cartItems]);
  return (
    <MainContext.Provider value={[cartItems, setCartItems, bill, setBill]}>
      {props.children}
    </MainContext.Provider>
  );
}

export default Manager;
