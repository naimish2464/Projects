const jsondata = [
    {
        "pid": "1",
        "img": require("./image/p1.jpg"),
        "pname": "Earphone",
        "price": 500
    },
    {
        "pid": "2",
        "img": require("./image/p2.jpg"),
        "pname": "Watch",
        "price": 300
    },
    {
        "pid": "3",
        "img": require("./image/p3.jpg"),
        "pname": "Mouse",
        "price": 400
    },
    {
        "pid": "4",
        "img": require("./image/p4.jpg"),
        "pname": "Bike",
        "price": 6000
    },
    {
        "pid": "5",
        "img": require("./image/p5.jpg"),
        "pname": "Cycle",
        "price": 4000
    },
    {
        "pid": "6",
        "img": require("./image/p6.jpg"),
        "pname": "Earbuds",
        "price": 800
    },
    {
        "pid": "7",
        "img": require("./image/p7.jpg"),
        "pname": "Goggle",
        "price": 100
    },
    {
        "pid": "8",
        "img": require("./image/p8.jpg"),
        "pname": "Mobile",
        "price": 5000
    },
    {
        "pid": "9",
        "img": require("./image/p9.jpg"),
        "pname": "Camera",
        "price": 500
    },
    {
        "pid": "10",
        "img": require("./image/p10.jpg"),
        "pname": "Laptop",
        "price": 70000
    }
];

export { jsondata };