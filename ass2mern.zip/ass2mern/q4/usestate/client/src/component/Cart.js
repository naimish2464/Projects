import React, { useContext } from 'react';
import MainContext from './MainContext';

const Cart = () => {
    const [cartItems, setCartItems, bill, setBill] = useContext(MainContext);

    const removeData = (value) => {
        const newItems = cartItems.filter((item) => item._id !== value._id);
        setCartItems(newItems);
    };

    const clearData = () => {
        setCartItems([]);
        setBill({});
    };

    const removeqty = (_id) => {
        if (bill[_id] > 1) {
            setBill((prevBill) => ({
                ...prevBill,
                [_id]: prevBill[_id] - 1,
            }));
        }
    };

    const addqty = (_id) => {
        setBill((prevBill) => ({
            ...prevBill,
            [_id]: (prevBill[_id] || 0) + 1,
        }));
    };

    const calculateTotalPrice = () => {
        let totalPrice = 0;
        for (const _id in bill) {
            const item = cartItems.find((cartItem) => cartItem._id === _id);
            if (item) {
                totalPrice += item.price * bill[_id];
            }
        }
        return totalPrice;
    };

    return (
        <>
            <h1>Cart</h1>
            <div className='row'>
                {cartItems.map((value, index) => (
                    <div className='col-md-3' key={index}>
                        <div className='card mb-4'>
                            <img
                                src={`/image/${value.img}`}
                                className='card-img-top'
                                alt={value.pname}
                                height='200px'
                            />
                            <div className='card-body'>
                                <h5 className='card-title'>{value.pname}</h5>
                                <p className='card-text'>Rs. {value.price}</p>

                                <div style={{ display: 'flex', justifyContent: 'center' }}>
                                    <button className='btn btn-info' onClick={() => removeqty(value._id)}>
                                        -
                                    </button>
                                    <h3>{bill[value._id]}</h3>
                                    <button className='btn btn-info' onClick={() => addqty(value._id)}>
                                        +
                                    </button>
                                </div>
                                <h3>Total: Rs. {value.price * (bill[value._id] || 0)}</h3>
                                <button className='btn btn-danger' onClick={() => removeData(value)}>
                                    Remove
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
                <h3>Pay Amount: Rs. {calculateTotalPrice()}</h3>
                <button className='btn btn-warning' onClick={() => clearData()}>
                    Clear Cart
                </button>
            </div>
        </>
    );
};

export default Cart;
