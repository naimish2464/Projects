import './App.css';
import Cart from './component/Cart';
import Manager from './component/Manager';
import Navbar from './component/Navbar';
import Product from './component/Product';
import { Route, Routes } from 'react-router-dom';
function App() {
  return (
    <div className="App">
      <Manager>
      <Navbar />
        <Routes>
          <Route path='/' exact element={<Product />} />
          <Route path='/cart' exact element={<Cart />} />
        </Routes>
      </Manager>


    </div>
  );
}
export default App;