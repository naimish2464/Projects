import './App.css';
import Usestateex from './UseState/Usestateex'
import { Route, Routes } from 'react-router-dom';
import Navbar from './UseState/Navbar';
import Billing from './rtk/Billing'
import Order from './Order';
function App() {
  return (
    <div className="App">
      <Navbar/>
      <Routes>
        <Route path='/' exact element={<Usestateex/>}/>
        <Route path='/Billing' exact element={<Billing/>}/>
        <Route path='/Order' exact element={<Order/>}/> 
      </Routes>
    </div>
  );
}

export default App;