import React, { useEffect, useState } from 'react'
import axios from 'axios';

const Order = () => {
  const [orderList, setorderList] = useState([]);
  const getOrderdata = async () => {
    const fetchorder = await axios.get('http://localhost:3001/api/getorder');
    console.clear();
    console.log(fetchorder.data);

    // if(fetchorder.data.items >= 1){
    setorderList(fetchorder.data);
    // }
  }
  const searchData = async (e) => {
    let item = e.target.value;

    if (item) {
      const searchdatas = await axios.get(`http://localhost:3001/api/searchitem/${item}`);
      if (searchdatas) {
        // if(searchData.data.items.qty >= 1){
        setorderList(searchdatas.data);
        // }
      }
    }
    else {
      getOrderdata();
    }
  }
  useEffect(() => {
    getOrderdata();
  }, [])

  // const filterData = () => {
  //   orderList.map((value, key) =>
  //   (
  //     <tr key={key}>
  //       <td>{value.name}</td>
  //       <td>{value.mno}</td>
  //       <center>
  //         {
  //           value.items.map((value1, key) => {

  //             // if (value1.qty >= 1) {
  //               return (
  //                 <>

  //                   <tr>
  //                     <td>ProductName:-{value1.name}</td>
  //                   </tr>
  //                   <tr>
  //                     <td>Price:-{value1.price}</td>
  //                   </tr>
  //                   <tr>
  //                     <td>Qty:-{value1.qty}</td>
  //                   </tr>
  //                 </>
  //               )
  //             // }
  //           })
            
  //         }
  //       </center>
  //       <td>{value.total}</td>

  //     </tr>
  //   )
  //   )
  // }

  return (
    <div>

      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"
        onChange={searchData} />
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Name</th>
            <th scope="col">MobileNumber</th>
            <th scope="col">OrderDetail</th>
            <th scope="col">Total</th>
          </tr>
        </thead>
        <tbody>
        
        {orderList.map((value,key)=>{
          return(

          
            <tr key={key}>
            <td>{value.name}</td>
            <td>{value.mno}</td>
            <center>
              {
                value.items.map((value1, key) => {
                  if (value1.qty >= 1) {
                    return (
                      <>
    
                        <tr>
                          <td>ProductName:-{value1.name}</td>
                        </tr>
                        <tr>
                          <td>Price:-{value1.price}</td>
                        </tr>
                        <tr>
                          <td>Qty:-{value1.qty}</td>
                        </tr>
                      </>
                    )
                  }
                })
              }
            </center>
            <td>{value.total}</td>
    
          </tr>
          )
        })}

        </tbody>
      </table>
    </div>
  )
}

export default Order