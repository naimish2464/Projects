import React, { useEffect, useState } from 'react'
import axios from 'axios';
const Usestateex = () => {

  const [list, setlist] = useState([])
  const [total, setTotal] = useState(0);
  const [name, setName] = useState('');
  const [mno, setmno] = useState('');

  const gettotal = (ndata) => {
    let fulltotaltemp = 0;
    ndata.forEach(element => {
      fulltotaltemp += Number(element.price);
    });
    setTotal(fulltotaltemp);
  }

  const fetchData = async () => {
    try {
      const response = await axios.get('http://localhost:3001/api/getitems');
      const newData = response.data.map((element) => ({
        _id: element._id,
        name: element.name,
        price: element.price,
        qty: 0,
      }));
      setlist(newData);
      // gettotal(newData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }

  };

  const handleQty = (value, operation) => {
    let temptotal = total;
    const templist = list.map((element) => {
      if (element._id === value._id) {
        if (operation === '+') {
          element.qty += 1;
          temptotal = Number(temptotal) + Number(element.price);
        }
        else if (operation === '-' && element.qty > 0) {
          element.qty -= 1;
          temptotal = Number(temptotal) - Number(element.price);
        }
        setTotal(temptotal);
      }
      return element;
    })
    // console.log(templist);
    setlist(templist);
  }
  const addorder = () => {
    
    // list.map((item,key)=>{
      // if(item.qty >= 1){
        axios.post('http://localhost:3001/api/addorder', {
          name,
          mno,
          list,
          total
        })
      // }
    // })
  }
  useEffect(() => {
    fetchData();
  }, [])

  return (
    <>
      {/* <form> */}
        <div class="mb-3">
          <div>UseStateex</div>
          < div Style="display:flex;">
            <label className='form-label'>Enter Your name </label>
            <input type='text' class="form-control" onChange={(e) => { setName(e.target.value) }} />
          </div >
          < div Style="display:flex;">
            <label className='form-label'> Mobile :</label>
            <input type='number' class="form-control" onChange={(e) => { setmno(e.target.value) }} />
          </div >
          <div>
            {
              list.map((value, key) => {
                return (
                  <>
                    < div key={key} >
                      {value.name} = {value.price}
                      < button className='btn btn-primary' onClick={() => { handleQty(value, '-') }} > -
                      </button>{value.qty}<button className='btn btn-primary' onClick={() => { handleQty(value, '+') }}> + </button>
                      {value.price * value.qty}
                    </div >
                  </>
                )
              })

            }

          </div>
          <div Style="display:flex;">
            Total = {total}
          </div>
          <button onClick={() => { addorder() }}>Order Now</button>
        </div >
      {/* </form> */}
    </>
  )
}

export default Usestateex