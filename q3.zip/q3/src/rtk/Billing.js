import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import axios from 'axios';
import { addItems, incrementqty, decrementqty } from './BillingSlice'
const Billing = () => {
    const list = useSelector((state) => state.billings)
    const [total, setTotal] = useState(0);
    const dispatch = useDispatch();
    const [name, setName] = useState('');
    const [mno, setmno] = useState('');

    const fetchData = async () => {
        try {
            const response = await axios.get('http://localhost:3001/api/getitems');
            const newData = response.data.map((element) => ({
                _id: element._id,
                name: element.name,
                price: element.price,
                qty: 1,
            }));
            dispatch(addItems(newData));
            gettotal(newData);

        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    const handleTotal = (value, operation) => {
        setTotal(0);
        let temptotal = total;
        list.map((element) => {
            if (element._id === value._id) {
                if (operation === '+') {
                    temptotal = Number(temptotal) + Number(element.price);
                }
                else if (operation === '-' && element.qty > 1) {
                    temptotal = Number(temptotal) - Number(element.price);
                }
                setTotal(temptotal);
            }
        })

    }

    const gettotal = (ndata) => {
        let fulltotaltemp = 0;
        ndata.forEach(element => {
            fulltotaltemp += Number(element.price);
        });
        setTotal(fulltotaltemp);
    }
    const addorder = () => {
        axios.post('http://localhost:3001/api/addorder', {
            name,
            mno,
            list,
            total
        })
    }
    useEffect(() => {
        fetchData();
    }, [])
    return (
        <h1>
            <div>Redux ToolKit</div>
            < div Style="display:flex;">
                Enter Your name
                <input type='text' onChange={(e) => { setName(e.target.value) }} />
            </div >
            < div Style="display:flex;">
                Enter Mobile Number
                <input type='number' onChange={(e) => { setmno(e.target.value) }} />
            </div >
            {
                list.map((value, key) => (
                    < div Style="display:flex;" key={key} >
                        {value.name} = {value.price}
                        < button onClick={() => { dispatch(decrementqty(value)); handleTotal(value, '-') }} > - </button>{value.qty}
                        <button onClick={() => { dispatch(incrementqty(value)); handleTotal(value, '+'); }}> + </button>{value.price * value.qty}
                    </div >

                )
                )
            }
            <div Style="display:flex;">
                Total = {total}
            </div>
            <button onClick={() => { addorder() }}>Order Now</button>
        </h1>
    )
}

export default Billing