import { configureStore } from "@reduxjs/toolkit";
import BillingSlice from "./BillingSlice";

export const store=configureStore({
    reducer:{
        billings:BillingSlice
    }
})