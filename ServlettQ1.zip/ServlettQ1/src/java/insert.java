
import java.sql.*;
import java.util.*;

public class insert {

    
 
    public Connection getConnect()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/jdbc";
            Connection con=DriverManager.getConnection(url,"admin","admin");
            System.out.println("Connected");
            
            return con;
        }catch(Exception e)
        {
            System.out.println(e);
        }
        
        return null;
    }
    
    void save(Employee e)
    {
        
         try{
            Connection con=getConnect();
            PreparedStatement smt=con.prepareStatement("Insert into tblemp (name,password,email,country) values (?,?,?,?)");
             smt.setString(1,e.getname());
             smt.setString(2,e.getpassword());
             smt.setString(3,e.getemail());
             smt.setString(4,e.getcountry());
            
             
           int status= smt.executeUpdate();
             smt.close();
             con.close();
             
        }catch(Exception ex)
        {
            System.out.println(ex);
        }     
    }
    
    void update()
    {
        try{
        Employee e=new Employee();
        Connection con=getConnect();
      
        PreparedStatement smt=con.prepareStatement("update tblemp set name=?,password=?,email=?,country=? where id=?");
              smt.setString(1,e.getname());
             smt.setString(4,e.getpassword());
             smt.setString(2,e.getemail());
             smt.setString(3,e.getcountry());
             smt.setInt(5,e.getid());  
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
    }
    
    public  int delete(int id){  
        int status=0;  
        try{  
            Connection con=getConnect();  
            PreparedStatement ps=con.prepareStatement("delete from tblemp where id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return status;  
    }  
    public Employee getEmployeeById(int id){  
        Employee e=new Employee();  
          
        try{  
            Connection con=getConnect();  
            PreparedStatement ps=con.prepareStatement("select * from tblemp where id=?");  
            ps.setInt(1,id);  
            ResultSet rs=ps.executeQuery();  
            if(rs.next()){  
                e.setid(rs.getInt(1));  
                e.setname(rs.getString(2));  
                e.setpassword(rs.getString(3));  
                e.setemail(rs.getString(4));  
                e.setcountry(rs.getString(5));  
            }  
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return e;  
    }  
    public  List<Employee> getAllEmployees(){  
        List<Employee> list=new ArrayList<Employee>();  
          
        try{  
            Connection con=getConnect();  
            PreparedStatement ps=con.prepareStatement("select * from tblemp");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
                Employee e=new Employee();  
                e.setid(rs.getInt(1));  
                e.setname(rs.getString(2));  
                e.setpassword(rs.getString(3));  
                e.setemail(rs.getString(4));  
                e.setcountry(rs.getString(5));  
                list.add(e);  
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return list;
    }
    
}
