/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author win
 */
public class Employee {
    private int id;
    private String name,password,email,country;
    
    public int getid()
    {
        return id;
    }
    public void setid(int id)
    {
        this.id=id;
    }
    
    public String getname()
    {
        return name;
    }
    public void setname(String name)
    {
        this.name=name;
    }
    
    public String getpassword()
    {
        return password;
    }
    public void setpassword(String password)
    {
        
        this.password=password;
    }
    
    public String getemail()
    {  
    return email;  
    }  
    public void setemail(String email) {  
        this.email = email;  
    }  
    public String getcountry()
    {  
        return country;  
    }  
    public void setcountry(String country)
    {  
        this.country = country;  
    }  
}
