
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class deleteservlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            
            
            String id = req.getParameter("id");
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "");
            PreparedStatement ps = conn.prepareStatement("delete from stud where id='"+id+"'");
            ps.executeUpdate();
            resp.sendRedirect("showuserservlet");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(deleteservlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
