
package Bean;

import java.sql.*;

public class Mycontact {

      
    
    public Mycontact() {
       
    }
    
    private String name;
    private String number;
    private String email;

    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }


    public void setNumber(String number) {
        this.number = number;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void insert()
    {
         try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javadb?zeroDateTimeBehavior=convertToNull","root","");
            String sql = "insert into tbl_bean(name,number,email) values('"+name+"','"+number+"','"+email+"')";
            Statement st = con.createStatement();
            st.execute(sql);
            st.close();
         
         }catch(Exception ex){
            System.out.println(ex);
        }
    }    
}
