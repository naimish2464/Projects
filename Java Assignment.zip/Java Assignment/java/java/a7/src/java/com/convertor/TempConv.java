
package com.convertor;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;


@WebService(serviceName = "TempConv")
public class TempConv {

  
    @WebMethod(operationName = "FahtoCel")
    public float FahtoCel(@WebParam(name = "temp") float temp) {
        
        float result = (temp-32)*5/9;
        return result;  
    }


    @WebMethod(operationName = "celtoferh")
    public float celtoferh(@WebParam(name = "temp") float temp) {
       
         float result = temp*9/5+32;
        return result;
    }
    
    
}
