

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author SONU
 */
@WebServlet(urlPatterns = {"/category"})
@MultipartConfig(
 fileSizeThreshold = 1024*1024*1,
 maxFileSize = 1024*1024*10,
 maxRequestSize = 1024*1024*15,
 location = "C:\\Users\\SONU\\Documents\\NetBeansProjects\\LoginModule\\images\\" 
)
public class category extends HttpServlet {

   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
           
             if(request.getParameter("upload")!=null){
            String cname = request.getParameter("came");
            String pname = request.getParameter("pame");
            String price = request.getParameter("price");
            String descp = request.getParameter("descp");
            //String image = request.getParameter("image");
             Part part1 = request.getPart("image");
             String imagename = part1.getSubmittedFileName();
             
             for(Part part :request.getParts()){
                if(part.getSize() > 100) {
                //out.println( part.getSubmittedFileName());
                part.write(part.getSubmittedFileName());
                out.println( part.getName());
                }
                }
            
            
            Connection con;
            try{
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javadb?zeroDateTimeBehavior=convertToNull","root","");
                String sql = "insert into tbl_category(cname,pname,price,descp,image) values('"+cname+"','"+pname+"','"+price+"','"+descp+"','"+imagename+"')";
                Statement st = con.createStatement();
                st.execute(sql);
                out.print("<script>\n" +
"                alert('Added Successfully');\n" +
"                window.location.href = 'category.jsp';\n" +
"            </script>");
                
            }catch(Exception ex){
                System.out.println(ex);
            }
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet category</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet category at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}}
