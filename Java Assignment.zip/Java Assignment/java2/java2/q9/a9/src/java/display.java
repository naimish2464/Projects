
import entity.TblEmp;
import entity.UserSessionBean;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author SONU
 */
public class display extends HttpServlet {
    @EJB
    private UserSessionBean userSessionBean;
    

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet display</title>");            
            out.println("</head>");
            out.println("<body>");
            out.print("<h1 align='center'>Our Employee</h1>");
            //view
             List<TblEmp> allEmp = userSessionBean.getAllEmp();
             out.print("<table border align='center'>");
                out.print("<thead>");
                out.print("<tr>");
                out.print("<th>ID</th>");
                out.print("<th>Name</th>");
                out.print("<th>City</th>");
                out.print("<th>Designation</th>");
                out.print("<th>Salary</th>");
                out.print("</tr>");
                out.print("</thead>");
                out.print("<tbody>");
            for (TblEmp e  : allEmp) {
                out.print("<tr>");
                out.print("<td>"+ e.getId() +"</td>");
                out.print("<td>"+ e.getEmpname() +"</td>");
                out.print("<td>"+e.getEmpcity() +"</td>");
                out.print("<td>"+ e.getEmpdesg()+"</td>");
                out.print("<td>"+ e.getEmpsalary()+"</td>");
                out.print("</tr>");             
            }
               out.print("</tbody>");
                out.print("<table>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
