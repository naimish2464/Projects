
package entity;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author SONU
 */
@Stateless
public class UserSessionBean {

    @PersistenceContext(unitName = "a9PU")
    private EntityManager em;

    //insert
    public void persist(Object object) {
        em.persist(object);
    }
    
    //display
    
    public List<TblEmp> getAllEmp() {
        Query listAllQuery = em.createNamedQuery("TblEmp.findAll");
        List<TblEmp> myEmpList = listAllQuery.getResultList(); 
        return myEmpList;
    }   
    
    

        
   

}
