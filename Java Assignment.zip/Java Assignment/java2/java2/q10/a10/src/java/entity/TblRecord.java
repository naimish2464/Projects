/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author SONU
 */
@Entity
@Table(name = "tbl_record")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TblRecord.findAll", query = "SELECT t FROM TblRecord t")
    , @NamedQuery(name = "TblRecord.findById", query = "SELECT t FROM TblRecord t WHERE t.id = :id")
    , @NamedQuery(name = "TblRecord.findByName", query = "SELECT t FROM TblRecord t WHERE t.name = :name")
    , @NamedQuery(name = "TblRecord.findByCity", query = "SELECT t FROM TblRecord t WHERE t.city = :city")
    , @NamedQuery(name = "TblRecord.findByMaterial", query = "SELECT t FROM TblRecord t WHERE t.material = :material")
    , @NamedQuery(name = "TblRecord.findByWages", query = "SELECT t FROM TblRecord t WHERE t.wages = :wages")})
public class TblRecord implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "city")
    private String city;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "material")
    private String material;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "wages")
    private String wages;

    public TblRecord() {
    }

    public TblRecord(Integer id) {
        this.id = id;
    }

    public TblRecord(Integer id, String name, String city, String material, String wages) {
        this.id = id;
        this.name = name;
        this.city = city;
        this.material = material;
        this.wages = wages;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getWages() {
        return wages;
    }

    public void setWages(String wages) {
        this.wages = wages;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TblRecord)) {
            return false;
        }
        TblRecord other = (TblRecord) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.TblRecord[ id=" + id + " ]";
    }
    
}
