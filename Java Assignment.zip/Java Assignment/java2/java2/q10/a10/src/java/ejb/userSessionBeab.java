/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.TblRecord;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author SONU
 */
@Stateless
public class userSessionBeab implements userSessionBeabLocal {

    @PersistenceContext(unitName = "a10PU")
    private EntityManager em;

    public void persist(Object object) {
        em.persist(object);
    }
    
    public List<TblRecord> getAllWages() {
        Query listAllQuery = em.createNamedQuery("TblRecord.findAll");
        List<TblRecord> myWagesList = listAllQuery.getResultList(); 
        return myWagesList;
    }  
  
    
    

  
}
