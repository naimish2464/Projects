/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.TblRecord;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author SONU
 */
@Local
public interface userSessionBeabLocal {

    public void persist(Object object);

    public List<TblRecord> getAllWages();
    
}
