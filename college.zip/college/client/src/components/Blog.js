import React from 'react'
import { useState, useEffect } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const Blog = () => {
    const Navigate=useNavigate();
    const [blogs, setBlogs] = useState([])
    const getAllBlogs = async () => {
        try {
            const { data } = await axios.get('http://localhost:5000/api/blog/getblog')
            if (data?.success) {
                setBlogs(data?.Blogs)
            }

        } catch (error) {
            console.log(error)
        }
    }
    useEffect(() => {
        getAllBlogs();

    }, [])
    return (
        <div>
        {

            blogs.map((item)=>{
                return  <div className="card" style={{width: "18rem"}}>
                <div className="card-body">
                    <h5 className="card-title">{item.title}</h5>
                    <p className="card-text">{item.content}</p>
                    <h6 className="card-subtitle mb-2 text-body-secondary">{item.author}</h6>
                    <button className="btn btn-primary m-1 " onClick={async()=>{
                        await axios.delete(`http://localhost:5000/api/blog/deleteblog/${item._id}`);

                         window.location.reload();
                   }}>Delete Blog</button>
                    <button className="btn btn-primary m-1" onClick={()=>{
                        Navigate(`/updateblog/${item._id}`)
                    }}

                    >update Blog</button>
                    
                </div>
            </div>
            })
        }
        </div>
    )
}

export default Blog