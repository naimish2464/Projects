import axios from 'axios';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

const CreateBlog = () => {
    const naviagte=useNavigate()
    const[title,setTitle]=useState();
    const[content,setContent]=useState();
    const[author,setauthor]=useState();


    const titleSubmit=(e)=>{
        setTitle(e.target.value);

    }

    const contentSubmit=(e)=>{
        setContent(e.target.value)
    }
    const authorSubmit=(e)=>{
        setauthor(e.target.value)
    }

   const handlesubmit=async(e)=>{
    e.preventDefault();
    const {data}=await axios.post('http://localhost:5000/api/blog/create',{
        title,content,author
    });
    if(data){
        console.log('data add success fully')
        naviagte('/blog')

    }

    }
    return (
        <div className="p-4 m-4 w-50 m-auto">

            <form onSubmit={handlesubmit}>
                <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">title</label>
                    <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" onChange={titleSubmit}/>
                        
                </div>
                <div className="mb-3">
                    <label for="exampleInputPassword1" className="form-label">content</label>
                    <input type="text" className="form-control" id="exampleInputPassword1" onChange={contentSubmit}/>
                </div>
                <div className="mb-3">
                <label for="exampleInputPassword1" className="form-label">author</label>
                <input type="text" className="form-control" id="exampleInputPassword1" onChange={authorSubmit}/>
            </div>
                
                <button type="submit" className="btn btn-primary">Submit</button>
            </form>
        </div>
    )
}

export default CreateBlog