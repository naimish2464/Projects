import Blog from './components/Blog';
import CreateBlog from './components/CreateBlog';
import Home from './components/Home';
import Navbar from './components/Navbar';
import UpdateBlog from './components/UpdateBlog';
import logo from './logo.svg';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Navbar/>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/blog' element={<Blog/>}></Route>
          <Route path='/createBlog' element={<CreateBlog/>}></Route>
          <Route path='/updateblog/:id' element={<UpdateBlog/>}></Route>
        </Routes>
      </BrowserRouter>


    </div>
  );
}

export default App;
