// routes/blogRoutes.js
const express = require('express');
const router = express.Router();
const blogModel = require('../models/blogSchema');

//addblog
router.post('/create',async(req,res)=>{
    const{title,content,author}=req.body;
    if(!title||!content||!author){
        return res.send({
            success: false,
            message:"the element not found"
        })
    }
    //existing user
    // const exstingUser=await blogModel.find({title});
    // if(exstingUser){
    //     return res.send({
    //         success: false,
    //         message:"the element already exists"
    //     })
    // }
    const blog=new blogModel({title,content,author});
    await blog.save();
    return res.send({
        success: true,
        message: 'the blog created successfully'
    })
})

//get the blog 

router.get("/getblog",async(req,res)=>{
    try {
        const Blogs=await blogModel.find({})
        if(!Blogs){
            return res.send({success:false, message:"the data not found"})
        }
        return res.send({success:true,
            blogcount:Blogs.length,
            message:"blog found",
            Blogs})
    } catch (error) {
        console.log(error);
    }
    

})

router.put("/updateblog/:id",async(req,res)=>{
    try {
     const{id}=req.params
     const {title,content,author}=req.body
     const blog=await blogModel.findByIdAndUpdate(id,{...req.body},{new:true});
     return res.send({
         success:true,
         message:"update successfully",
         blog
     })
     
    } catch (error) {
     console.log(error);
    }
 })


 router.delete("/deleteblog/:id",async(req,res)=>{
    try {
        const blog=await blogModel.findByIdAndDelete(req.params.id);
        await blog.user.blogs.filter(blog);
        await blog.user.save();
        return res.send({success:true,message:"blog deleted"})
    } catch (error) {
        console.log(error);
    }

})
module.exports = router;
