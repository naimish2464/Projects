const mongoose=require('mongoose');

const dbconnect=async()=>{
   const db=await mongoose.connect('mongodb://localhost:27017/blogapp2');
   if(db){
    console.log('connection is successful');
   }else{
    console.log('connetion is not successful');
   }
}

module.exports=dbconnect;