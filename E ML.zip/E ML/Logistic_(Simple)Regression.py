import pandas as pd
import matplotlib.pyplot as plt

#Importing Data

df=pd.read_csv('Logistc_Reg_insurance_data.csv')
print(df)



# set Data


x=df[['age']].values
y=df[['bought_insurance']].values

# splitting Into Training and testing

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.25,random_state=0)

# Logistic Regression

from sklearn.linear_model import LogisticRegression
reg=LogisticRegression()
reg.fit(x_train,y_train)

#predicting Test 

y_pred=reg.predict(x_test)

print(y_pred)

# Test Confusion Matrix Of Result

from sklearn.metrics import confusion_matrix,accuracy_score
print("ConfusionMatrix : ")

cm=confusion_matrix(y_test,y_pred)
print(cm)

#Test Accuracy of 

print("accuracy Score : ")
accuracy=accuracy_score(y_test,y_pred)
print(accuracy)

plt.scatter(x="age", y="bought_insurance", color='blue', label='Data Points')
plt.xlabel('Age')
plt.ylabel('Bought Insurance')
plt.legend(loc='best')
plt.title('Logistic Regression Results')
plt.show()