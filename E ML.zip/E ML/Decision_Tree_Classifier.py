import pandas as pd

df=pd.read_csv('PlayTennis(Decision_Tree).csv')
print(df)

# Set data into numeric

from sklearn.preprocessing import LabelEncoder,OneHotEncoder

outlook=LabelEncoder()
temp=LabelEncoder()
humidity=LabelEncoder()
Windy=LabelEncoder()
play=LabelEncoder()

df['outlook']=outlook.fit_transform(df['outlook'])
df['temp']=outlook.fit_transform(df['temp'])
df['humidity']=outlook.fit_transform(df['humidity'])
df['windy']=outlook.fit_transform(df['windy'])
df['play']=outlook.fit_transform(df['play'])

print(df)

x=df[['outlook','temp','humidity','windy']]
y=df[['play']]

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)

from sklearn.tree import DecisionTreeClassifier
classif=DecisionTreeClassifier(criterion='gini')
classif.fit(x_train,y_train)

print("Classifier Score  :",classif.score(x_test,y_test))

from sklearn import tree
print("Treee : ")

tree.plot_tree(classif)
