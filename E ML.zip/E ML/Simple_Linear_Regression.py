# Simple Linear Regression

import pandas as pd

import matplotlib.pyplot as plt
df=pd.read_csv(r'F:\VNSGU\SEM-3\301 Machine Learning\insurance.csv')
print(df)

x=df[['age']].values
y=df[['premium']].values

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=1,random_state=0)


from sklearn.linear_model import LinearRegression  

reg= LinearRegression()  
reg.fit(x_train,y_train)

# Prediction of test set Result
y_pred=reg.predict(x_test)
x_pred=reg.predict(x_train)


#visulising training set result

plt.scatter(x_train,y_train,color="green")
plt.plot(x_train,x_pred,color="red")
plt.title("Age by Premium")
plt.xlabel("age")
plt.ylabel("premium")
plt.show()



print("Coefficients: ", reg.coef_)
print("Intercept: ", reg.intercept_)

print("prediction of 21 age premium :")
print(reg.predict([[21]]))