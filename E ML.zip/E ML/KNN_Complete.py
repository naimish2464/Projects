import sklearn as sk
from sklearn import datasets
from sklearn import neighbors
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
from sklearn import neighbors
#from sklearn.neighbors import KNeighborsClassifier
from sklearn import preprocessing

print("<><><><><><><><>< PROGRAM STARTS ><><><><><><><><<><><><><>")

iris  = datasets.load_iris()

print(iris)
print(type(iris))
print('---------------------')

X=iris.data
Y=iris.target
X_train,X_test,Y_train,Y_test=train_test_split(X,Y, test_size=0.33,random_state=1)

model = sk.neighbors.KNeighborsClassifier(n_neighbors=2,weights='distance',metric="manhattan")
model.fit(X_train,Y_train)

dataClass=model.predict (X_test)
print("The iris type is : ")
print(iris.target_names[dataClass])
print(accuracy_score(Y_test,dataClass))

print("\n\nConfusion Matrix\n",confusion_matrix(Y_test,dataClass,labels=[0,1,2]))
print("<<>><<<>><<>><<>><<>>PROGRAM ENDS <<>><<>><<>><<>><<>> ")
