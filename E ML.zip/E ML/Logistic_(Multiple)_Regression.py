import pandas as pd
from sklearn import datasets

iris=pd.read_csv('iris.csv')

print(iris.head())



# set species column into number format
iris['Species'].replace({'Iris-setosa':'1','Iris-versicolor ':'2','Iris-virginica':'3'},inplace=True)
print(iris)

# settle into x and y
x=iris[['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalLengthCm']]
y=iris[['Species']]

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)

from sklearn.linear_model import LogisticRegression
reg=LogisticRegression()
reg.fit(x_train,y_train)

y_pred=reg.predict(x_test)


from sklearn.metrics import confusion_matrix,accuracy_score

cm=confusion_matrix(y_test,y_pred)
print("Confusion Matrix  : ")
print(cm)

accuracy=accuracy_score(y_test,y_pred)
print("Accuracy Score is : ",accuracy)

'''

import matplotlib.pyplot as plt
plt.scatter(x,y,colour="blue",label="data Points")
plt.xlabel("Data")
plt.ylabel("target")
plt.legend(loc="best")
plt.title("Multiple Lofgistic Regression")
plt.show()
'''