import plotly.express as px
import pandas as pd

# Assuming you have loaded your data into a DataFrame df
fig = px.scatter( x='total_bill', y='tip', color='sex', title='Total Bill vs. Tip by Gender')
fig.show()
