import pandas as pd

df=pd.read_csv('practice.csv')

print(df)

# 
from sklearn.impute import SimpleImputer

imputer=SimpleImputer(strategy='most_frequent')
imputer.fit_transform(df.height)
print(df)