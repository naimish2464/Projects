import pandas as pd

df=pd.read_csv('insurance_data2.csv')
print(df)

# Filling the Missing data in height column
print("------------------------------ Filling the Missing data in height column -----------------------------\n")
mean_height=df.height.mean()
df.height=df.height.fillna(mean_height)

print(df)

x=df[['age','height','weight']]
y=df[['premium']]

print("-----------------------------Model Fitting-------------------------------------\n")

# Model fitting

from sklearn.linear_model import LinearRegression


reg=LinearRegression()
reg.fit(x,y)

print("cofficient  : ",reg.coef_)
print("Intercept : ",reg.intercept_)

print("prediction of Premium of  New data of age 50 :",reg.predict([[27,167.56,60]]))
