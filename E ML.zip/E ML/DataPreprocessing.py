# Compelete Program for Data PreProcessing 
import numpy as np
import pandas as pd
import sklearn as sk

print("-------------------dataset Importing ---------------------")

# importing the Dataset
dataset=pd.read_csv('Data.csv')
print(dataset)
# Splitting into (y)depenent var and (x)Independendent var
x=dataset[['Country','Age','Salary']].values
y=dataset[['Purchased']].values

print("-------------------- Missing Values finding---------------------\n")

# Finding missing Values in dataset (find mean)
from sklearn.impute import SimpleImputer
imputer=SimpleImputer(missing_values=np.nan,strategy='mean')
imputer=imputer.fit(x[:,1:3])
x[:,1:3]=imputer.transform(x[:,1:3])


print("------------------- Encoding Categorical Data------------------\n")
# Encoding Categorical Data
from sklearn.preprocessing import LabelEncoder
label_encoder_x=LabelEncoder()
x[:,0]=label_encoder_x.fit_transform(x[:,0])


from sklearn.preprocessing import OneHotEncoder
OneH=OneHotEncoder()
x = OneH.fit_transform(dataset.Country.values.reshape(-1,1)).toarray()

label_encoder_y=LabelEncoder()
y=label_encoder_y.fit_transform(y)

print("---------------Splitting into Training and Testing set --------------\n")
# Splitting Dataset Into Trainig And Testing set
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=0)

#Feauture Scaling
print("--------------------Feature Scaling--------------------------\n")
from sklearn.preprocessing import StandardScaler
sc_x=StandardScaler()
x_train=sc_x.fit_transform(x_train)
x_test=sc_x.transform(x_test)

print(x_train)
print("\n\n")
print(x_test)

print("------------------------- Program Ends --------------------")