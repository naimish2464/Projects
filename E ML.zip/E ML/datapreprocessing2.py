import pandas as pd

df=pd.read_csv("data.csv")

print(df)

x=df[['Country','Age','Salary']].values
y=df[['Purchased']].values

# ----------------------------- Fillling the Missing Value ------------------------------- #

mean_sal=df.Salary.mean()
df.Salary=df.Salary.fillna(mean_sal)

mean_age=df.Age.mean()
df.Age=df.Age.fillna(mean_age)

print(df)


# -------------------------------- Encoding Values ----------------------------------- #

from sklearn.preprocessing import OneHotEncoder,LabelEncoder

ohe=OneHotEncoder()
le=LabelEncoder()

x=ohe.fit_transform(df.Country.values.reshape(-1,1)).toarray()
y=le.fit_transform(y)

# ---------------------------------------   Splitting into training data -----------------------  #

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=0)


# ----------------------------------------- Standard Scaling -------------------------------------  #
from sklearn.preprocessing import StandardScaler

st=StandardScaler()
x_train=st.fit_transform(x_train)
x_test=st.transform(x_test)

print("x : ",x_train)
print(" x_test : ",x_test)

