import pandas as pd

print("----------------------------- Program starts --------------------------")
print('--------------------------Print Dataset -----------------------------=')
df=pd.read_csv('income.csv')
print(df)


print(' ------------------------------ Visulizing Dataset -------------------------')
import matplotlib.pyplot as plt

plt.scatter(df['Age'],df['Income($)'])
plt.xlabel('Age')
plt.ylabel('Income')
plt.show()

print('---------------------------- Selecting K Points to Clusters --------------------------')
# Data Devided into k=3 cluster [k0,k1,k2]
from sklearn.cluster import KMeans

km=KMeans(n_clusters=3)
y_pred=km.fit_predict(df[['Age','Income($)']])
df['cluster']=y_pred

print(df)

km.cluster_centers_

df1=df[df.cluster==0]
df2=df[df.cluster==1]
df3=df[df.cluster==2]

plt.scatter(df1.Age,df1['Income($)'],color='green')
plt.scatter(df2.Age,df2['Income($)'],color='red')
plt.scatter(df3.Age,df3['Income($)'],color='blue')
plt.xlabel('Age')
plt.ylabel('Income')
plt.legend()
plt.show()


print(' ---------------------------- Place centroid in Each cluster ---------------------')
from sklearn.preprocessing import MinMaxScaler
scaler=MinMaxScaler()
scaler.fit(df[['Income($)']])
df['Income($)']=scaler.transform(df[['Income($)']])

scaler.fit(df[['Age']])
df['Age']=scaler.transform(df[['Age']])


km=KMeans(n_clusters=3)
y_pred=km.fit_predict(df[['Age','Income($)']])
df['cluster']=y_pred

print(df)

km.cluster_centers_

df1=df[df.cluster==0]
df2=df[df.cluster==1]
df3=df[df.cluster==2]

plt.scatter(df1.Age,df1['Income($)'],color='green')
plt.scatter(df2.Age,df2['Income($)'],color='red')
plt.scatter(df3.Age,df3['Income($)'],color='blue')
plt.scatter(km.cluster_centers_[:,0],km.cluster_centers_[:,1],color='purple',marker='*',label='centroid')
plt.xlabel('Age')
plt.ylabel('Income')
plt.legend()
plt.show()

print(' ----------------------------- sum of Squre error --------------------------')
sse=[]
range= range(1,10)
for k in range:
    km=KMeans(n_clusters=k)
    km.fit(df[['Age','Income($)']])
    sse.append(km.inertia_)

plt.xlabel('K')
plt.ylabel('Sum of Squre Error ')
plt.plot(range,sse)
plt.show()