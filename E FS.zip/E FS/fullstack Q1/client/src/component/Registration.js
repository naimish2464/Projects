import React, { useState } from 'react'
import axios from 'axios';
function Registration() {

    const [firstName, setfirstName] = useState('');
    const [lastName, setlastName] = useState('');
    const [gender, setgender] = useState('');
    const [username, setusername] = useState('');
    const [email, setemail] = useState('');
    const [mno, setmno] = useState('');
    const [city, setcity] = useState('Surat');
    const [state, setstate] = useState('');
    const [password, setpassword] = useState('');

    const putData = () => {
        axios.post('http://localhost:3001/student/addstud', {
            firstName,
            lastName,
            gender,
            username,
            email,
            mno,
            city,
            state,
            password
        })
            setfirstName("");
            setlastName("");
            setgender("");
            setusername("");
            setemail('');
            setmno('');
            setcity('');
            setstate('');
            setpassword('');
    }
    return (
        <>
            <div className="regbox">
                        
                <div className="row g-3">
                    <div className="col-sm-6">
                        <label htmlFor="firstName" className="form-label">First name</label>
                        <input type="text" className="form-control" name="firstName" value={firstName} onChange={(e) => { setfirstName(e.target.value) }} placeholder="" required />
                    </div>

                    <div className="col-sm-6">
                        <label htmlFor="lastName" className="form-label">Last name</label>
                        <input type="text" className="form-control" name="lastName" value={lastName} onChange={(e) => { setlastName(e.target.value) }} placeholder="" required />
                    </div>

                    <div className="col-12">
                        <label htmlFor="username" className="form-label">Gender</label>
                        <input type="radio" name="gender" value="male" onChange={(e) => { setgender(e.target.value) }} />Male<input type="radio" name="gender" value="female" onChange={(e) => { setgender(e.target.value) }} />Female
                    </div>


                    <div className="col-12">
                        <label htmlFor="username" className="form-label">Username</label>
                        <div className="input-group has-validation">
                            <span className="input-group-text">@</span>
                            <input type="text" className="form-control" name="username" placeholder="" value={username} onChange={(e) => { setusername(e.target.value) }} required />
                        </div>
                    </div>

                    <div className="col-12">
                        <label htmlFor="email" className="form-label">Email</label>
                        <input type="email" className="form-control" name="email" placeholder="" value={email} onChange={(e) => { setemail(e.target.value) }} required />
                    </div>
                    <div className="col-12">
                        <label htmlFor="mno" className="form-label">Mobile Number</label>
                        <input type="number" size="10" className="form-control" name="mno" placeholder="" value={mno} onChange={(e) => { setmno(e.target.value) }} required />
                    </div>
                    <div className="col-sm-6">
                        <label htmlFor="city" className="form-label">City</label>
                        <select name='city' value={city} onChange={(e) => { setcity(e.target.value) }}>
                            <option>Surat</option>
                            <option>Udaipur</option>
                            <option>Pune</option>
                        </select>
                    </div>

                    <div className="col-sm-6">
                        <label htmlFor="state" className="form-label">State</label>
                        <input type="text" className="form-control" name="state" placeholder="" value={state} onChange={(e) => { setstate(e.target.value) }} required />
                    </div>

                    <div className="col-12">
                        <label htmlFor="password" className="form-label">Password</label>
                        <input type="password" className="form-control" name="password" placeholder="" value={password} onChange={(e) => { setpassword(e.target.value) }} required />
                    </div>
                    <div className="col-12">
                        <label htmlFor="cpassword" className="form-label">Confirm Password</label>
                        <input type="password" className="form-control" name="cpassword" placeholder="" required />
                    </div>
                    <button className="btn btn-outline-primary mb-3" onClick={() => { putData() }}>Register</button>

                </div>

            </div>
        </>
    )
}

export default Registration