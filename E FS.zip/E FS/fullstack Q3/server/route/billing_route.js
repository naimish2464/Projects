const express = require('express');
const itemModel = require('../model/item_model');
const route = express.Router();

route.post('/additems', (req, resp) => {
    const data = new itemModel({
        name: req.body.name,
        price: req.body.price
    })
    data.save();
    resp.send("done");
})

route.get('/getitems', async (req, resp) => {
    const data = await itemModel.find();

    resp.send(data);
})

module.exports = route;