const express = require('express');
const orderModel = require('../model/order_model')
const route = express.Router();

route.post('/addorder', (req, resp) => {
   
    const data = new orderModel({
        name: req.body.name,
        mno: req.body.mno,
        items:req.body.list,
        total:req.body.total
    })
    data.save();
    resp.send("orderAdded");
})

route.get('/getorder',async(req,resp)=>{
    const data=await orderModel.find();
    resp.send(data);
})

route.get('/searchitem/:key',async(req,resp)=>{
    const item=req.params.key;
    const data=await orderModel.find({
        "$or":[
            {name:{$regex:item}}
        ]
    })
    resp.send(data);
})

module.exports = route;