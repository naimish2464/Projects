import React, { useContext, useEffect, useState } from 'react';
import axios from 'axios';
import MainContext from './MainContext';

const Product = () => {

    const [jsondata, setjsondata] = useState([]);
    const fetchrec = async () => {
        const fetchitem = await axios.get('http://localhost:3001/items/getItems');
        setjsondata(fetchitem.data);
    }
    const [cartItems, setCartItems] = useContext(MainContext);
    const putData = (value) => {
        const found = cartItems.find((item) => item._id === value._id)
        if (!found) {
            setCartItems([...cartItems, value]);
        }
    };
    useEffect(() => {
        fetchrec();
    }, [])
    return (
        <div>
            <h1>Product</h1>
            <div className='row'>
                {jsondata.map((value, index) => (
                    <div className='col-md-3' key={index}>
                        <div className='card mb-4'>
                        <img src={`/image/${value.img}`} className='card-img-top' alt={value.pname} height='200px' />
                            <div className='card-body'>
                                <h5 className='card-title'>{value.pname}</h5>
                                <p className='card-text'>Rs. {value.price}</p>
                                <button className='btn btn-primary' onClick={() => putData(value)}>
                                    Add To Cart
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            <hr />
        </div>
    );
};

export default Product;