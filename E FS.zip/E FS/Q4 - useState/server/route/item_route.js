const express=require('express');
const router=express.Router();
const itemSchema = require('../model/item_model');

router.post('/addItem',async(req,resp)=>{
    const data=new itemSchema({
        img:req.body.img,
        pname:req.body.pname,
        price:req.body.price
    })
    await data.save();
    resp.send("done");
})

router.get('/getItems',async(req,resp)=>{
    const data=await itemSchema.find();
    resp.send(data);
})

module.exports=router;