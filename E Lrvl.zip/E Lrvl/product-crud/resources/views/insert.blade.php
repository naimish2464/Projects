<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center>
        <div>
            <h1>Insert  Data  </h1>
        </div>
        <div>
            <form action="{{ route('insert') }}" method="POST" enctype="multipart/form-data">
                @csrf
            <label for="">Enter Image</label><br>
            <input type="file" name="image" ><br>
            
            <label for="">Name : </label><br>
            <input type="text" name="name"><br>
            <label for="">Description :</label><br>
            <input type="textarea" name="description" id=""><br>
            <label for="">Price : </label><br>
            <input type="number" name="Price"><br>
            <input type="submit" name="submit" value="insert"> <br>
            </form>
        </div>
        <br><br>
        <div>

            <table border>
                <tr>
                    <th>id</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                    @foreach ($data as $p)
                        <tr>
                            
                            <td>{{ $p['id'] }}</td>
                            <td><img src="public/images/{{$p['image']}}" alt="image" height="100px" width="100px"></td>
                            <td>{{ $p['name'] }}</td>
                            <td>{{ $p['description'] }}</td>
                            <td>{{ $p['Price']}} </td>
                            <td><a href="edit/{{ $p['id'] }}">Edit</a></td>
                            <td><a href="delete/{{ $p['id'] }}">Delete</a></td>
                        </tr>
                    @endforeach
            </table>
        </div>
    </center>

</body>
</html>