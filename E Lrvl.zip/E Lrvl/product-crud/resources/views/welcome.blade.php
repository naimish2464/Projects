<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center>
        <div>
            <h1>Insert Data  </h1>
        </div>
        <div>
            <label for="">Enter Image</label><br>
            <input type="file" name="image" ><br>
            
            <label for="">Name : </label><br>
            <input type="text" name="name"><br>
            <label for="">Description :</label><br>
            <input type="textarea" name="description" id=""><br>
            <label for="">Price : </label><br>
            <input type="number" name="Price"><br>
            <input type="submit" name="submit" value="insert"> <br>
        </div>
        <div>
            <table>
                <tr>
                    <th>id</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th><a href="#">Edit</a></th>
                    <th><a href="#">Delete</a></th>
                </tr>
                    @foreach ($data as $p)
                        <tr>
                            
                            <td>{{ $p['id'] }}</td>
                            <td>{{ $p['image'] }}</td>
                            <td>{{ $p['name'] }}</td>
                            <td>{{ $p['description'] }}</td>
                            <td>{{ $p['Price']}} </td>
                            
                        </tr>
                    @endforeach
            </table>
        </div>
    </center>

</body>
</html>