<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center>
        <div><h1>Edit product</h1></div>
        <div>
        <div>
            <form action="{{url('updateform',$data->id)}}" method="POST" enctype="multipart/form-data">
                @csrf
            <label for="">Enter Image</label><br>
            <img src="public/images/{{$data->image}}"  value="image" alt="" height="100px" width="100px">
            <input type="file" name="image" value="{{$data->image}}" ><br>
            
            <label for="">Name : </label><br>
            <input type="text" name="name" value="{{$data->name}}"><br>
            <label for="">Description :</label><br>
            <input type="textarea" name="description" value="{{$data->description}}" id=""><br>
            <label for="">Price : </label><br>
            <input type="number" name="Price" value="{{$data->Price}}"><br><br>
            <input type="submit" name="submit" value="insert"> <br>
            </form>
        </div>
        <br><br>
        
    </center>
</body>
</html>