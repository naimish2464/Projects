<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\productmodel;

class productController extends Controller
{
    //
    public function insert(Request $req)
    {
        

        $name = $req->get('name');
        $description=$req->get('description');
        $price=$req->get('Price');
        

        $model=new productmodel();
        $model->name = $name;
        $model->description = $description;
        $model->Price = $price;

        if($req->file('image'))
        {
            $image=$req->file('image');
            $ext=$image->getClientOriginalExtension();
            $imagename= time().'.'.$ext;
            $image->move('public/images',$imagename);
            $model->image =$imagename;
        }
       
        $model->save();
            return back();
    }
    
    public function display()
    {
        $data =productmodel::all();
        return view('insert', ['data' => $data]);
    }

    public function delete($id)
    {
        productmodel::destroy($id);
        return back();
    }

    public function editform($id)
    {
        $data=productmodel::find($id);
        return view('edit',compact('data'));
    }   

    public function updateform(Request $req,$id)
    {
        $data=productmodel::find($id);
        $data->name=$req->input('name');
        $data->description=$req->input('description');
        $data->Price=$req->input('Price');
        if($req->file('image'))
        {
            $image=$req->file('image');
            $ext=$image->getClientOriginalExtension();
            $imagename= time().'.'.$ext;
            $image->move('public/images/',$imagename);
            $data->image =$imagename;
        }
       
        $data->save();
            return redirect('display');

    }
}
