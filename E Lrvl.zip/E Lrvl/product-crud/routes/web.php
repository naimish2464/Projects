<?php

use Illuminate\Support\Facades\Route;
use App\Models\productmodel;
use App\Http\Controllers\productController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('insert');
});

Route::get('/',[productController::class,'display']);
Route::post('insert',[productController::class,'insert'])->name('insert');
Route::post('updateform/{id}',[productController::class,'updateform'])->name('updateform');

Route::get('show',[productController::class,'display']);

Route::get('delete/{id}',[productController::class,'delete']);
Route::get('edit/{id}',[productController::class,'editform']);
