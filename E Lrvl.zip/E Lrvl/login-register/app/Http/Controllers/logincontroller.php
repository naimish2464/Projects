<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Hash;

class logincontroller extends Controller
{
    //

    public function login()
    {
        return view ('loginpage');
    }
    public function check(Request $req)
    {
        $creditionals=$req->validate([
            'email' =>['required','email'],
            'password'=>['required']
        ]);

        if(Auth::attempt($creditionals))
        {
            return view ('thanks');
        }
        return "<h2>invalid input or password</h2>";
    }
}
