<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\mymodel;
use Illuminate\Support\Facades\Auth;
use Hash;

class registercontroller extends Controller
{
    //
    public function register(Request $req)
    {
        $data=$req->all();

        mymodel::create([
            'name'=>$data['name'],
            'email'=>$data['email'],
            'password'=>Hash::make($data['password'])
            
        ]);
        return view ('loginpage');
    }
}
