<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\usermodel;
use Illuminate\Support\Facades\Auth;
use Hash;
class userController extends Controller
{
    //
public function create(Request $req){
    $data = $req->all();
    usermodel::create([
        'name'=>$data['name'],
        'email'=>$data['email'],
        'mobile'=>$data['mobile'],
        'password'=>Hash::make($data['password'])

    ]);
    return view('loginpage');
}
   
}
