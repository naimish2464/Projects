<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\usermodel;
use Illuminate\Support\Facades\Auth;
use Hash;

class logincontroller extends Controller
{
    //
    public function index()
    {
        return view ('loginpage');
    }
    public function check(Request $req)
    {
        $credentials=$req->validate([
            'email'=>['required','email'],
            'password'=>['required'],
        ]);

        if (Auth::attempt($credentials)) {
            $user = Auth::user(); // Get the authenticated user
    
            // Pass the user's information to the "thanks" view
            return view('thanks', [
                'name' => $user->name,
                'email' => $user->email,
                'mobile' => $user->mobile, // Assuming 'mobile' is a field in your User model
            ]);
        } else {
            return "<h2>Invalid login or password</h2>";
        }
    }

    

    
}
