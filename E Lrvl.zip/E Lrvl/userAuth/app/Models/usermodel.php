<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

use Hash;

class usermodel extends Model
{
   protected $table = "tbluser";
   protected $fillable =['name','email','mobile','password'];
   public $timestamps= false;
}
