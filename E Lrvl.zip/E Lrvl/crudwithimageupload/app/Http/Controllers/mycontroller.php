<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\mymodel;

class mycontroller extends Controller
{

    public function store(Request $req)
    {
        $data=new mymodel();
       $data->name=$req->input('name');
       $data->gender=$req->input('gender');
       $data->country=$req->input('country');

       //checkbox
       $checkbox_data=$req->input('skill');
       $data->skill=implode(',',$checkbox_data);

       //image
       if($req->file('image'))
       {
        $image=$req->file('image');
        $ext=$image->getClientOriginalExtension();
        $image_name=time().".".$ext;
        $image->move('public/images',$image_name);

        $data->image=$image_name;
       }
       $data->save();
       return back();

    }

    public function display()
    {
        $data=mymodel::all();
        return view('display',['product' =>$data]);
    }
    public function delete($id)
    {
        $data=mymodel::destroy($id);
        return redirect('/display');
    }

    public function editdata($id)
    {
        $data=mymodel::find($id);
        return view ('update',compact('data'));
    }


    public function update(Request $req,$id)
    {
        $data=mymodel::find($id);
        $data->name=$req->input('name');
        $data->description=$req->input('description');
        $data->Price=$req->input('Price');

        
            if($req->file('image'))
            {
                $image=$req->file('image');
                $ext=$image->getClientOriginalExtension();
                $image_name=time().".".$ext;
                $image->move('public/images',$image_name);
        
                $data->image=$image_name;
            }
        $data->save();
        return back();
    }
    

}
