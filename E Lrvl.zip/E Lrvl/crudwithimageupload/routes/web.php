<?php

use Illuminate\Support\Facades\Route;
use App\Models\mymodel;
use App\Http\Controllers\mycontroller;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('/store',[mycontroller::class,'store'])->name('store');

Route::get('/display',[mycontroller::class,'display']);

Route::get('edit/{id}',[mycontroller::class,'editdata']);

Route::get('delete/{id}',[mycontroller::class,'delete']);

Route::post('update/{id}',[mycontroller::class,'update']);
