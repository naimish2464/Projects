<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border="2">
        @foreach($product as $d)
        <tr>
            <td>{{$d->id}}</td>
            <td><img src="public/images/{{$d->image}}" alt="" height="100px" width="100px"></td>
            <td>{{$d->name}}</td>
            <td>{{$d->description}}</td>
            <td>{{$d->Price}}</td>
            <td><a href="edit/{{$d->id}}">Edit</a></td>
            <td><a href="delete/{{$d->id}}">Delete</a></td>
        </tr>
        @endforeach
    </table>
</body>
</html>