const express = require('express');
const router = express.Router();
const userinfo = require('../model/stud_model');
router.post('/addstud', (req, resp) => {
    const data = new userinfo({
        fname: req.body.firstName,
        lname: req.body.lastName,
        gender: req.body.gender,
        uname: req.body.username,
        email: req.body.email,
        mno: req.body.mno,
        city: req.body.city,
        state: req.body.state,
        password: req.body.password
    })
    data.save();
    resp.send("done");
})

router.get('/getstud', async (req, resp) => {
    const data = await userinfo.find();
    resp.send(data);
})

router.delete('/removestud/:id', async (req, resp) => {
    const id = req.params.id;
    await userinfo.findByIdAndDelete(req.params.id);
    resp.send('done');
})

router.get('/Editstud/:id', async (req, resp) => {
    const data = await userinfo.findById(req.params.id);
    resp.json(data);
})

router.put('/Updatestud/:id', async (req, resp) => {

    const data = {
        fname: req.body.firstName,
        lname: req.body.lastName,
        gender: req.body.gender,
        uname: req.body.username,
        email: req.body.email,
        mno: req.body.mno,
        city: req.body.city,
        state: req.body.state
    }
    await userinfo.findByIdAndUpdate(req.params.id, data);
    resp.send("updated");
})

router.get('/searchstud/:key', async (req, resp) => {
    const key=req.params.key;
    const data=await userinfo.find({
        "$or":[
            {fname:{$regex:key}},
            {city:{$regex:key}},
            {mno:{$regex:key}}
        ]
    })
    resp.send(data);
})

module.exports = router;