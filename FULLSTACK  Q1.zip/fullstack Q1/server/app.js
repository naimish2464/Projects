const express = require('express');
const mongoose = require('mongoose');
const route = require('./route/stud_route');
const app = express();
const cors=require('cors');
mongoose.connect('mongodb://127.0.0.1:27017/student');
app.use(express.json());
app.use(cors());
app.use('/student',route);

app.listen(3001, () => {
    console.log("server is running at 3001");
})