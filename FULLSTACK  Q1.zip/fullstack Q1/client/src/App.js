import './App.css';
import Navbar from './component/Navbar';
import Reg from './component/Registration'
import { Routes, Route } from 'react-router-dom';
import ShowUser from './component/ShowUser';
import Editstud from './component/Editstud';
function App() {
  return (
    <div className="App">
      <Navbar />
      <Routes>
        <Route path='/' exact element={<Reg />} />
        <Route path='/display' exact element={<ShowUser />} />
        <Route path='/Editstud/:id' exact element={<Editstud />} />
      </Routes>
    </div>
  );
}

export default App;