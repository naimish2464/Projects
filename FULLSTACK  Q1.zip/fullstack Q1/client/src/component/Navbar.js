import React from 'react'
import {NavLink} from 'react-router-dom';
const Navbar = () => {
    return (
        <>
        <nav className="navbar navbar-expand-lg bg-body-tertiary">
            <div className="container-fluid">
                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                <nav class="navbar navbar-expand-lg bg-body-tertiary">
                    <div class="container-fluid">
                        <a class="navbar-brand" href="#">Navbar</a>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Home</a>
                                </li>
                                <li class="nav-item">
                                <NavLink className="nav-link active" aria-current="page" to="/">AddStudent</NavLink>
                                </li>
                                <li class="nav-item">
                                <NavLink className="nav-link" to="/display">ShowUser</NavLink>
                                </li>
                        
                            </ul>
                            </div>
                            
                        </div>
                       
                    </nav>
                </div>
            </div>
        </nav>
        </>
    )
}

export default Navbar
